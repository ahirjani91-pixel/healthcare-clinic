import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import dotenv from 'dotenv';
import express, {NextFunction, Request, Response} from 'express';
import {
  INITIAL_CUSTOMERS,
  INITIAL_EXPENSES,
  INITIAL_LEDGER,
  INITIAL_PRODUCTS,
  INITIAL_TRANSACTIONS,
  INITIAL_USERS,
} from './src/data/demoData.ts';
import type {
  AuthSession,
  Customer,
  ExpenseRecord,
  LedgerEntry,
  PlatformUser,
  Product,
  TradeLineItem,
  TradeTransaction,
  UserStatus,
} from './src/types/dukaan.ts';

dotenv.config();

const PORT = Number(process.env.PORT) || 3000;
const SESSION_SECRET =
  process.env.SESSION_SECRET && process.env.SESSION_SECRET.trim().length >= 16
    ? process.env.SESSION_SECRET.trim()
    : crypto.randomBytes(32).toString('hex');

const OWNER_EMAIL = (process.env.SUPER_ADMIN_EMAIL || 'ahirjani91@gmail.com')
  .trim()
  .toLowerCase();

const DATA_DIR = path.resolve(process.cwd(), '.data');
const DB_FILE = path.resolve(DATA_DIR, 'dukaanpro-store.json');

interface ScryptHash {
  salt: string;
  hash: string;
}

interface UserCredential extends ScryptHash {
  isDemoSeed?: boolean;
}

interface ServerStore {
  adminCredential: ScryptHash | null;
  userCredentials: Record<string, UserCredential>;
  users: PlatformUser[];
  products: Product[];
  transactions: TradeTransaction[];
  customers: Customer[];
  ledgerEntries: LedgerEntry[];
  expenses: ExpenseRecord[];
}

interface TokenPayload extends AuthSession {
  iat: number;
  exp: number;
}

interface AuthedRequest extends Request {
  auth?: TokenPayload;
}

function hashSecret(plain: string): ScryptHash {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(plain, salt, 64).toString('hex');
  return {salt, hash};
}

function verifySecret(plain: string, stored: ScryptHash): boolean {
  if (!plain || !stored?.salt || !stored?.hash) return false;
  const derived = crypto.scryptSync(plain, stored.salt, 64);
  const expected = Buffer.from(stored.hash, 'hex');
  if (derived.length !== expected.length) return false;
  return crypto.timingSafeEqual(derived, expected);
}

function verifyPlainEqual(a: string, b: string): boolean {
  const da = crypto.createHash('sha256').update(a).digest();
  const db = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(da, db);
}

function signToken(session: AuthSession): string {
  const now = Math.floor(Date.now() / 1000);
  const payload: TokenPayload = {
    ...session,
    iat: now,
    exp: now + 60 * 60 * 12, // 12 hours
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

function verifyToken(token: string): TokenPayload | null {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  if (!encoded || !sig) return null;

  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');

  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }

  try {
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as TokenPayload;
    const now = Math.floor(Date.now() / 1000);
    if (!payload.exp || payload.exp < now) return null;
    if (payload.role !== 'super_admin' && payload.role !== 'business_user') return null;
    return payload;
  } catch {
    return null;
  }
}

function createInitialStore(): ServerStore {
  const userCredentials: Record<string, UserCredential> = {};
  for (const u of INITIAL_USERS) {
    userCredentials[u.id] = {
      salt: '',
      hash: '',
      isDemoSeed: true,
    };
  }
  return {
    adminCredential: null,
    userCredentials,
    users: structuredClone(INITIAL_USERS),
    products: structuredClone(INITIAL_PRODUCTS),
    transactions: structuredClone(INITIAL_TRANSACTIONS),
    customers: structuredClone(INITIAL_CUSTOMERS),
    ledgerEntries: structuredClone(INITIAL_LEDGER),
    expenses: structuredClone(INITIAL_EXPENSES),
  };
}

function loadStore(): ServerStore {
  try {
    if (!DB_FILE.startsWith(DATA_DIR + path.sep)) {
      throw new Error('Invalid store path');
    }
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf8');
      const parsed = JSON.parse(raw) as Partial<ServerStore>;
      if (parsed && Array.isArray(parsed.users) && Array.isArray(parsed.products)) {
        return {
          adminCredential: parsed.adminCredential ?? null,
          userCredentials: parsed.userCredentials ?? {},
          users: parsed.users,
          products: parsed.products,
          transactions: parsed.transactions ?? [],
          customers: parsed.customers ?? [],
          ledgerEntries: parsed.ledgerEntries ?? [],
          expenses: parsed.expenses ?? [],
        };
      }
    }
  } catch {
    // Fall back to clean seed store
  }
  const initial = createInitialStore();
  persistStore(initial);
  return initial;
}

function persistStore(store: ServerStore): void {
  if (!DB_FILE.startsWith(DATA_DIR + path.sep)) {
    throw new Error('Invalid store path');
  }
  fs.mkdirSync(DATA_DIR, {recursive: true});
  const tmpFile = path.resolve(DATA_DIR, `dukaanpro-store.${process.pid}.tmp`);
  if (!tmpFile.startsWith(DATA_DIR + path.sep)) {
    throw new Error('Invalid temp store path');
  }
  fs.writeFileSync(tmpFile, JSON.stringify(store, null, 2), 'utf8');
  fs.renameSync(tmpFile, DB_FILE);
}

const store: ServerStore = loadStore();

function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

function getEnvAdminPasscode(): string {
  return (process.env.ADMIN_PASSCODE || '').trim();
}

function isAdminPasscodeConfigured(): boolean {
  return getEnvAdminPasscode().length > 0 || store.adminCredential !== null;
}

function sanitizeString(val: unknown, maxLen = 140): string {
  if (typeof val !== 'string') return '';
  return val.trim().slice(0, maxLen);
}

function requireAuth(req: AuthedRequest, res: Response, next: NextFunction): void {
  const header = req.headers.authorization || '';
  const match = /^Bearer\s+(.+)$/i.exec(header);
  if (!match) {
    res.status(401).json({error: 'Authentication required.'});
    return;
  }
  const payload = verifyToken(match[1]);
  if (!payload) {
    res.status(401).json({error: 'Session expired or invalid. Please sign in again.'});
    return;
  }
  req.auth = payload;
  next();
}

function requireSuperAdmin(req: AuthedRequest, res: Response, next: NextFunction): void {
  if (!req.auth || req.auth.role !== 'super_admin' || req.auth.email.toLowerCase() !== OWNER_EMAIL) {
    res.status(403).json({error: 'Forbidden: Only the platform Super Admin can access this resource.'});
    return;
  }
  next();
}

function requireBusinessUser(req: AuthedRequest, res: Response, next: NextFunction): void {
  if (!req.auth || req.auth.role !== 'business_user' || !req.auth.businessId) {
    res.status(403).json({error: 'Forbidden: Business user session required.'});
    return;
  }
  const user = store.users.find((u) => u.id === req.auth?.userId);
  if (!user) {
    res.status(401).json({error: 'User account no longer exists.'});
    return;
  }
  if (user.isBlocked) {
    res.status(403).json({error: 'Your account has been blocked by the administrator.'});
    return;
  }
  if (user.status !== 'active') {
    res.status(403).json({error: 'Your account is currently deactivated. Please contact the administrator.'});
    return;
  }
  next();
}

async function startServer() {
  const app = express();
  app.use(express.json({limit: '1mb'}));

  // --- Auth Endpoints ---
  app.get('/api/auth/admin/status', (_req, res) => {
    res.json({
      isPasscodeConfigured: isAdminPasscodeConfigured(),
      ownerEmail: OWNER_EMAIL,
    });
  });

  // One-time owner passcode setup when ADMIN_PASSCODE env var is unset and no admin hash exists yet
  app.post('/api/auth/admin/setup', (req, res) => {
    if (isAdminPasscodeConfigured()) {
      res.status(409).json({error: 'Owner passcode is already configured.'});
      return;
    }
    const email = sanitizeString(req.body?.email, 160).toLowerCase();
    const passcode = typeof req.body?.passcode === 'string' ? req.body.passcode.trim() : '';

    if (email !== OWNER_EMAIL) {
      res.status(403).json({error: 'Only the designated platform owner email can claim admin access.'});
      return;
    }
    if (passcode.length < 6) {
      res.status(400).json({error: 'Owner passcode must be at least 6 characters long.'});
      return;
    }

    store.adminCredential = hashSecret(passcode);
    persistStore(store);

    const session: AuthSession = {
      role: 'super_admin',
      userId: 'super-admin-owner',
      email: OWNER_EMAIL,
      name: 'Platform Owner',
    };
    const token = signToken(session);
    res.status(201).json({token, session});
  });

  app.post('/api/auth/admin/login', (req, res) => {
    if (!isAdminPasscodeConfigured()) {
      res.status(403).json({error: 'Owner passcode not set up yet. Complete first-time setup.'});
      return;
    }
    const email = sanitizeString(req.body?.email, 160).toLowerCase();
    const passcode = typeof req.body?.passcode === 'string' ? req.body.passcode.trim() : '';

    if (email !== OWNER_EMAIL) {
      res.status(403).json({error: 'Unauthorized administrator email address.'});
      return;
    }

    const envPasscode = getEnvAdminPasscode();
    const valid =
      envPasscode.length > 0
        ? verifyPlainEqual(passcode, envPasscode)
        : store.adminCredential
        ? verifySecret(passcode, store.adminCredential)
        : false;

    if (!valid) {
      res.status(401).json({error: 'Invalid owner passcode.'});
      return;
    }

    const session: AuthSession = {
      role: 'super_admin',
      userId: 'super-admin-owner',
      email: OWNER_EMAIL,
      name: 'Platform Owner',
    };
    const token = signToken(session);
    res.json({token, session});
  });

  app.post('/api/auth/business/login', (req, res) => {
    const email = sanitizeString(req.body?.email, 160).toLowerCase();
    const password = typeof req.body?.password === 'string' ? req.body.password : '';

    const user = store.users.find((u) => u.email.toLowerCase() === email);
    if (!user) {
      res.status(401).json({error: 'No business account found with that email.'});
      return;
    }
    if (user.isBlocked) {
      res.status(403).json({error: 'This account has been blocked by the platform administrator.'});
      return;
    }
    if (user.status !== 'active') {
      res.status(403).json({error: 'This account is currently deactivated. Contact the platform administrator.'});
      return;
    }

    const cred = store.userCredentials[user.id];
    if (!cred || !cred.hash || !verifySecret(password, cred)) {
      res.status(401).json({
        error: cred?.isDemoSeed
          ? 'Please use the Quick Demo sign-in button for sample accounts.'
          : 'Invalid email or password.',
      });
      return;
    }

    user.lastActiveAt = todayISO();
    persistStore(store);

    const session: AuthSession = {
      role: 'business_user',
      userId: user.id,
      email: user.email,
      name: user.name,
      businessId: user.businessId,
    };
    res.json({token: signToken(session), session});
  });

  app.post('/api/auth/business/demo', (req, res) => {
    const email = sanitizeString(req.body?.email, 160).toLowerCase();
    const user = store.users.find((u) => u.email.toLowerCase() === email);
    const cred = user ? store.userCredentials[user.id] : undefined;
    if (!user || !cred?.isDemoSeed) {
      res.status(403).json({error: 'Demo sign-in is only available for seeded sample accounts.'});
      return;
    }
    if (user.isBlocked) {
      res.status(403).json({error: 'This account has been blocked by the platform administrator.'});
      return;
    }
    if (user.status !== 'active') {
      res.status(403).json({error: 'This account is currently deactivated. Contact the platform administrator.'});
      return;
    }

    user.lastActiveAt = todayISO();
    persistStore(store);

    const session: AuthSession = {
      role: 'business_user',
      userId: user.id,
      email: user.email,
      name: user.name,
      businessId: user.businessId,
    };
    res.json({token: signToken(session), session});
  });

  app.post('/api/auth/business/register', (req, res) => {
    const name = sanitizeString(req.body?.name, 100);
    const email = sanitizeString(req.body?.email, 160).toLowerCase();
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const phone = sanitizeString(req.body?.phone, 30) || '+91 98000 00000';
    const businessName = sanitizeString(req.body?.businessName, 140);
    const businessCategory = sanitizeString(req.body?.businessCategory, 80) || 'Kirana & Groceries';
    const city = sanitizeString(req.body?.city, 80);
    const state = sanitizeString(req.body?.state, 80) || 'Maharashtra';
    const gstin = sanitizeString(req.body?.gstin, 24).toUpperCase() || 'UNREGISTERED';

    if (!name || !email || !businessName || !city) {
      res.status(400).json({error: 'Owner name, email, business name, and city are required.'});
      return;
    }
    if (password.length < 6) {
      res.status(400).json({error: 'Password must be at least 6 characters long.'});
      return;
    }
    if (email === OWNER_EMAIL || store.users.some((u) => u.email.toLowerCase() === email)) {
      res.status(409).json({error: 'An account with this email already exists.'});
      return;
    }

    const userId = `usr-${Date.now()}`;
    const businessId = `biz-${Date.now()}`;
    const today = todayISO();

    const newUser: PlatformUser = {
      id: userId,
      name,
      email,
      phone,
      businessId,
      businessName,
      businessCategory,
      city,
      state,
      gstin,
      status: 'active',
      isBlocked: false,
      joinedAt: today,
      lastActiveAt: today,
    };

    store.userCredentials[userId] = hashSecret(password);
    store.users.unshift(newUser);
    persistStore(store);

    const session: AuthSession = {
      role: 'business_user',
      userId,
      email: newUser.email,
      name: newUser.name,
      businessId,
    };
    res.status(201).json({token: signToken(session), session});
  });

  app.get('/api/auth/me', requireAuth, (req: AuthedRequest, res) => {
    const auth = req.auth!;
    if (auth.role === 'super_admin') {
      res.json({session: auth, user: null});
      return;
    }
    const user = store.users.find((u) => u.id === auth.userId);
    if (!user || user.isBlocked || user.status !== 'active') {
      res.status(403).json({error: 'Account unavailable or restricted.'});
      return;
    }
    res.json({session: auth, user});
  });

  // --- Super Admin RBAC Protected Endpoints ---
  app.get('/api/admin/users', requireAuth, requireSuperAdmin, (_req, res) => {
    const totalUsers = store.users.length;
    const activeUsers = store.users.filter((u) => u.status === 'active' && !u.isBlocked).length;
    const deactivatedUsers = store.users.filter((u) => u.status === 'deactivated').length;
    const blockedUsers = store.users.filter((u) => u.isBlocked).length;

    res.json({
      stats: {
        totalUsers,
        activeUsers,
        deactivatedUsers,
        blockedUsers,
        totalBusinesses: totalUsers,
      },
      users: store.users,
    });
  });

  app.patch('/api/admin/users/:id', requireAuth, requireSuperAdmin, (req, res) => {
    const user = store.users.find((u) => u.id === req.params.id);
    if (!user) {
      res.status(404).json({error: 'User not found.'});
      return;
    }

    const name = sanitizeString(req.body?.name, 100);
    const email = sanitizeString(req.body?.email, 160).toLowerCase();
    const phone = sanitizeString(req.body?.phone, 30);
    const businessName = sanitizeString(req.body?.businessName, 140);
    const businessCategory = sanitizeString(req.body?.businessCategory, 80);
    const city = sanitizeString(req.body?.city, 80);
    const state = sanitizeString(req.body?.state, 80);
    const gstin = sanitizeString(req.body?.gstin, 24).toUpperCase();
    const ownerNotes = typeof req.body?.ownerNotes === 'string' ? req.body.ownerNotes.trim().slice(0, 400) : undefined;

    if (email && email !== user.email.toLowerCase()) {
      if (email === OWNER_EMAIL || store.users.some((u) => u.id !== user.id && u.email.toLowerCase() === email)) {
        res.status(409).json({error: 'Email is already assigned to another account.'});
        return;
      }
      user.email = email;
    }

    if (name) user.name = name;
    if (phone) user.phone = phone;
    if (businessName) user.businessName = businessName;
    if (businessCategory) user.businessCategory = businessCategory;
    if (city) user.city = city;
    if (state) user.state = state;
    if (gstin) user.gstin = gstin;
    if (ownerNotes !== undefined) user.ownerNotes = ownerNotes;

    persistStore(store);
    res.json({user});
  });

  app.post('/api/admin/users/:id/status', requireAuth, requireSuperAdmin, (req, res) => {
    const user = store.users.find((u) => u.id === req.params.id);
    if (!user) {
      res.status(404).json({error: 'User not found.'});
      return;
    }
    const status = req.body?.status as UserStatus;
    if (status !== 'active' && status !== 'deactivated') {
      res.status(400).json({error: 'Status must be active or deactivated.'});
      return;
    }
    user.status = status;
    persistStore(store);
    res.json({user});
  });

  app.post('/api/admin/users/:id/block', requireAuth, requireSuperAdmin, (req, res) => {
    const user = store.users.find((u) => u.id === req.params.id);
    if (!user) {
      res.status(404).json({error: 'User not found.'});
      return;
    }
    if (typeof req.body?.isBlocked !== 'boolean') {
      res.status(400).json({error: 'isBlocked boolean is required.'});
      return;
    }
    user.isBlocked = req.body.isBlocked;
    persistStore(store);
    res.json({user});
  });

  app.delete('/api/admin/users/:id', requireAuth, requireSuperAdmin, (req, res) => {
    const target = store.users.find((u) => u.id === req.params.id);
    if (!target) {
      res.status(404).json({error: 'User not found.'});
      return;
    }
    const bizId = target.businessId;
    store.users = store.users.filter((u) => u.id !== target.id);
    delete store.userCredentials[target.id];
    store.products = store.products.filter((p) => p.businessId !== bizId);
    store.customers = store.customers.filter((c) => c.businessId !== bizId);
    store.transactions = store.transactions.filter((t) => t.businessId !== bizId);
    store.ledgerEntries = store.ledgerEntries.filter((l) => l.businessId !== bizId);
    store.expenses = store.expenses.filter((e) => e.businessId !== bizId);
    persistStore(store);
    res.json({deletedId: target.id});
  });

  // --- Scoped Business Workspace Endpoints ---
  app.get('/api/business/workspace', requireAuth, requireBusinessUser, (req: AuthedRequest, res) => {
    const bizId = req.auth!.businessId!;
    const user = store.users.find((u) => u.id === req.auth!.userId)!;
    res.json({
      user,
      products: store.products.filter((p) => p.businessId === bizId),
      transactions: store.transactions.filter((t) => t.businessId === bizId),
      customers: store.customers.filter((c) => c.businessId === bizId),
      ledgerEntries: store.ledgerEntries.filter((l) => l.businessId === bizId),
      expenses: store.expenses.filter((e) => e.businessId === bizId),
    });
  });

  app.post('/api/business/products', requireAuth, requireBusinessUser, (req: AuthedRequest, res) => {
    const bizId = req.auth!.businessId!;
    const name = sanitizeString(req.body?.name, 140);
    if (!name) {
      res.status(400).json({error: 'Product name is required.'});
      return;
    }
    const product: Product = {
      id: `prd-${Date.now()}`,
      businessId: bizId,
      sku: sanitizeString(req.body?.sku, 40) || `SKU-${Date.now()}`,
      name,
      category: sanitizeString(req.body?.category, 60) || 'General',
      unit: sanitizeString(req.body?.unit, 20) || 'Pack',
      purchasePrice: Math.max(0, Number(req.body?.purchasePrice) || 0),
      sellingPrice: Math.max(0, Number(req.body?.sellingPrice) || 0),
      gstRate: Math.max(0, Number(req.body?.gstRate) || 0),
      stock: Math.max(0, Number(req.body?.stock) || 0),
      minStock: Math.max(0, Number(req.body?.minStock) || 0),
      updatedAt: todayISO(),
    };
    store.products.unshift(product);
    persistStore(store);
    res.status(201).json({product});
  });

  app.patch('/api/business/products/:id', requireAuth, requireBusinessUser, (req: AuthedRequest, res) => {
    const bizId = req.auth!.businessId!;
    const prod = store.products.find((p) => p.id === req.params.id && p.businessId === bizId);
    if (!prod) {
      res.status(404).json({error: 'Product not found.'});
      return;
    }
    const name = sanitizeString(req.body?.name, 140);
    if (name) prod.name = name;
    if (typeof req.body?.sku === 'string') prod.sku = sanitizeString(req.body.sku, 40) || prod.sku;
    if (typeof req.body?.category === 'string') prod.category = sanitizeString(req.body.category, 60) || prod.category;
    if (typeof req.body?.unit === 'string') prod.unit = sanitizeString(req.body.unit, 20) || prod.unit;
    if (req.body?.purchasePrice !== undefined) prod.purchasePrice = Math.max(0, Number(req.body.purchasePrice) || 0);
    if (req.body?.sellingPrice !== undefined) prod.sellingPrice = Math.max(0, Number(req.body.sellingPrice) || 0);
    if (req.body?.gstRate !== undefined) prod.gstRate = Math.max(0, Number(req.body.gstRate) || 0);
    if (req.body?.stock !== undefined) prod.stock = Math.max(0, Number(req.body.stock) || 0);
    if (req.body?.minStock !== undefined) prod.minStock = Math.max(0, Number(req.body.minStock) || 0);
    prod.updatedAt = todayISO();
    persistStore(store);
    res.json({product: prod});
  });

  app.post('/api/business/products/:id/stock', requireAuth, requireBusinessUser, (req: AuthedRequest, res) => {
    const bizId = req.auth!.businessId!;
    const prod = store.products.find((p) => p.id === req.params.id && p.businessId === bizId);
    if (!prod) {
      res.status(404).json({error: 'Product not found.'});
      return;
    }
    const delta = Number(req.body?.delta) || 0;
    prod.stock = Math.max(0, prod.stock + delta);
    prod.updatedAt = todayISO();
    persistStore(store);
    res.json({product: prod});
  });

  app.delete('/api/business/products/:id', requireAuth, requireBusinessUser, (req: AuthedRequest, res) => {
    const bizId = req.auth!.businessId!;
    const before = store.products.length;
    store.products = store.products.filter((p) => !(p.id === req.params.id && p.businessId === bizId));
    if (store.products.length === before) {
      res.status(404).json({error: 'Product not found.'});
      return;
    }
    persistStore(store);
    res.json({deletedId: req.params.id});
  });

  app.post('/api/business/transactions', requireAuth, requireBusinessUser, (req: AuthedRequest, res) => {
    const bizId = req.auth!.businessId!;
    const type = req.body?.type === 'purchase' ? 'purchase' : 'sale';
    const items = Array.isArray(req.body?.items) ? req.body.items : [];
    if (items.length === 0) {
      res.status(400).json({error: 'At least one line item is required.'});
      return;
    }

    const prefix = type === 'sale' ? 'INV' : 'PUR';
    const voucherNo = `${prefix}-2026-${Math.floor(1100 + Math.random() * 8800)}`;

    const rawCustomerId = typeof req.body?.customerId === 'string' ? req.body.customerId : undefined;
    const validCustomer = rawCustomerId
      ? store.customers.find((c) => c.id === rawCustomerId && c.businessId === bizId)
      : undefined;

    const sanitizedItems: TradeLineItem[] = items
      .map((raw: Record<string, unknown>): TradeLineItem => ({
        productId: sanitizeString(raw?.productId, 60),
        productName: sanitizeString(raw?.productName, 140),
        qty: Math.max(1, Math.floor(Number(raw?.qty) || 0)),
        unit: sanitizeString(raw?.unit, 20) || 'Pcs',
        rate: Math.max(0, Number(raw?.rate) || 0),
        gstRate: Math.max(0, Number(raw?.gstRate) || 0),
        lineTotal: Math.max(0, Number(raw?.lineTotal) || 0),
      }))
      .filter((item: TradeLineItem) => Boolean(item.productId && item.productName));

    if (sanitizedItems.length === 0) {
      res.status(400).json({error: 'Valid line items are required.'});
      return;
    }

    const trx: TradeTransaction = {
      id: `trx-${Date.now()}`,
      businessId: bizId,
      voucherNo,
      type,
      partyName: sanitizeString(req.body?.partyName, 140) || 'Walk-in Cash Counter',
      partyPhone: sanitizeString(req.body?.partyPhone, 30) || '—',
      customerId: validCustomer?.id,
      items: sanitizedItems,
      subtotal: Math.max(0, Number(req.body?.subtotal) || 0),
      gstAmount: Math.max(0, Number(req.body?.gstAmount) || 0),
      totalAmount: Math.max(0, Number(req.body?.totalAmount) || 0),
      paidAmount: Math.max(0, Number(req.body?.paidAmount) || 0),
      dueAmount: Math.max(0, Number(req.body?.dueAmount) || 0),
      paymentMode: req.body?.paymentMode || 'UPI',
      date: sanitizeString(req.body?.date, 20) || todayISO(),
      notes: sanitizeString(req.body?.notes, 200) || undefined,
    };

    for (const item of trx.items) {
      const prod = store.products.find((p) => p.id === item.productId && p.businessId === bizId);
      if (prod) {
        prod.stock =
          type === 'sale' ? Math.max(0, prod.stock - item.qty) : prod.stock + item.qty;
        prod.updatedAt = todayISO();
      }
    }

    let createdLedger: LedgerEntry | null = null;
    if (type === 'sale' && trx.dueAmount > 0 && trx.customerId) {
      createdLedger = {
        id: `led-${Date.now()}`,
        businessId: bizId,
        customerId: trx.customerId,
        customerName: trx.partyName,
        type: 'udhar',
        amount: trx.dueAmount,
        mode: 'Credit Bill',
        date: trx.date,
        note: `Credit balance on ${voucherNo}`,
        referenceVoucher: voucherNo,
      };
      store.ledgerEntries.unshift(createdLedger);
    }

    store.transactions.unshift(trx);
    persistStore(store);
    res.status(201).json({transaction: trx, ledgerEntry: createdLedger});
  });

  app.post('/api/business/customers', requireAuth, requireBusinessUser, (req: AuthedRequest, res) => {
    const bizId = req.auth!.businessId!;
    const name = sanitizeString(req.body?.name, 120);
    if (!name) {
      res.status(400).json({error: 'Customer name is required.'});
      return;
    }
    const customer: Customer = {
      id: `cust-${Date.now()}`,
      businessId: bizId,
      name,
      phone: sanitizeString(req.body?.phone, 30) || '+91 98000 00000',
      city: sanitizeString(req.body?.city, 60) || 'Local',
      gstin: sanitizeString(req.body?.gstin, 24).toUpperCase() || undefined,
      openingBalance: Number(req.body?.openingBalance) || 0,
      createdAt: todayISO(),
    };
    store.customers.unshift(customer);
    persistStore(store);
    res.status(201).json({customer});
  });

  app.patch('/api/business/customers/:id', requireAuth, requireBusinessUser, (req: AuthedRequest, res) => {
    const bizId = req.auth!.businessId!;
    const cust = store.customers.find((c) => c.id === req.params.id && c.businessId === bizId);
    if (!cust) {
      res.status(404).json({error: 'Customer not found.'});
      return;
    }
    const name = sanitizeString(req.body?.name, 120);
    if (name) cust.name = name;
    if (typeof req.body?.phone === 'string') cust.phone = sanitizeString(req.body.phone, 30) || cust.phone;
    if (typeof req.body?.city === 'string') cust.city = sanitizeString(req.body.city, 60) || cust.city;
    if (typeof req.body?.gstin === 'string') cust.gstin = sanitizeString(req.body.gstin, 24).toUpperCase() || undefined;
    if (req.body?.openingBalance !== undefined) cust.openingBalance = Number(req.body.openingBalance) || 0;
    persistStore(store);
    res.json({customer: cust});
  });

  app.post('/api/business/ledger', requireAuth, requireBusinessUser, (req: AuthedRequest, res) => {
    const bizId = req.auth!.businessId!;
    const customerId = sanitizeString(req.body?.customerId, 60);
    const cust = store.customers.find((c) => c.id === customerId && c.businessId === bizId);
    if (!cust) {
      res.status(404).json({error: 'Customer not found in your business.'});
      return;
    }
    const amount = Math.max(1, Number(req.body?.amount) || 0);
    const entry: LedgerEntry = {
      id: `led-${Date.now()}`,
      businessId: bizId,
      customerId: cust.id,
      customerName: cust.name,
      type: req.body?.type === 'udhar' ? 'udhar' : 'jama',
      amount,
      mode: req.body?.mode || 'UPI',
      date: sanitizeString(req.body?.date, 20) || todayISO(),
      note: sanitizeString(req.body?.note, 200) || 'Ledger entry',
    };
    store.ledgerEntries.unshift(entry);
    persistStore(store);
    res.status(201).json({entry});
  });

  app.post('/api/business/expenses', requireAuth, requireBusinessUser, (req: AuthedRequest, res) => {
    const bizId = req.auth!.businessId!;
    const title = sanitizeString(req.body?.title, 140);
    if (!title) {
      res.status(400).json({error: 'Expense title is required.'});
      return;
    }
    const expense: ExpenseRecord = {
      id: `exp-${Date.now()}`,
      businessId: bizId,
      title,
      category: req.body?.category || 'Other',
      amount: Math.max(1, Number(req.body?.amount) || 0),
      paymentMode: req.body?.paymentMode || 'UPI',
      date: sanitizeString(req.body?.date, 20) || todayISO(),
      vendor: sanitizeString(req.body?.vendor, 100) || undefined,
      notes: sanitizeString(req.body?.notes, 200) || undefined,
    };
    store.expenses.unshift(expense);
    persistStore(store);
    res.status(201).json({expense});
  });

  app.delete('/api/business/expenses/:id', requireAuth, requireBusinessUser, (req: AuthedRequest, res) => {
    const bizId = req.auth!.businessId!;
    const before = store.expenses.length;
    store.expenses = store.expenses.filter((e) => !(e.id === req.params.id && e.businessId === bizId));
    if (store.expenses.length === before) {
      res.status(404).json({error: 'Expense record not found.'});
      return;
    }
    persistStore(store);
    res.json({deletedId: req.params.id});
  });

  // --- Vite Dev Middleware / Production Static Serving ---
  if (process.env.NODE_ENV !== 'production') {
    const {createServer: createViteServer} = await import('vite');
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`DukaanPro server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start DukaanPro server:', err);
  process.exit(1);
});
