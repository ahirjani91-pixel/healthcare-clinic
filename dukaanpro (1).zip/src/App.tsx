import React from 'react';
import {AdminLayout} from './components/admin/AdminLayout';
import {AuthPortal} from './components/auth/AuthPortal';
import {BusinessLayout} from './components/business/BusinessLayout';
import {OfflineIndicator} from './components/pwa/OfflineIndicator';
import {AppProvider, useApp} from './context/AppContext';

const AppRouter: React.FC = () => {
  const {session, activeBusinessUser} = useApp();

  if (!session) {
    return <AuthPortal />;
  }

  if (session.role === 'super_admin') {
    return <AdminLayout />;
  }

  // Strictly block deactivated or blocked business users
  if (
    !activeBusinessUser ||
    activeBusinessUser.status !== 'active' ||
    activeBusinessUser.isBlocked
  ) {
    return <AuthPortal />;
  }

  return <BusinessLayout />;
};

export default function App() {
  return (
    <AppProvider>
      <AppRouter />
      <OfflineIndicator />
    </AppProvider>
  );
}
