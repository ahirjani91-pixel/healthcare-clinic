import React, {useMemo, useState} from 'react';
import {Building2, Edit3, MapPin, Search, ShieldOff} from 'lucide-react';
import {useApp} from '../../context/AppContext';
import {PlatformUser} from '../../types/dukaan';
import {formatDateIN} from '../../utils/formatters';
import {EmptyState} from '../ui/EmptyState';
import {Modal} from '../ui/Modal';

export const AdminBusinesses: React.FC = () => {
  const {users, updateUserAndBusiness, setUserStatus, setUserBlocked} = useApp();
  const [query, setQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [editingBiz, setEditingBiz] = useState<PlatformUser | null>(null);

  const [formBizName, setFormBizName] = useState('');
  const [formCategory, setFormCategory] = useState('');
  const [formCity, setFormCity] = useState('');
  const [formState, setFormState] = useState('');
  const [formGstin, setFormGstin] = useState('');
  const [formNotes, setFormNotes] = useState('');

  const categories = useMemo(
    () => ['All', ...Array.from(new Set(users.map((u) => u.businessCategory)))],
    [users]
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return users.filter((u) => {
      if (categoryFilter !== 'All' && u.businessCategory !== categoryFilter) return false;
      if (!q) return true;
      return (
        u.businessName.toLowerCase().includes(q) ||
        u.city.toLowerCase().includes(q) ||
        u.gstin.toLowerCase().includes(q) ||
        u.name.toLowerCase().includes(q)
      );
    });
  }, [users, query, categoryFilter]);

  const openEdit = (u: PlatformUser) => {
    setEditingBiz(u);
    setFormBizName(u.businessName);
    setFormCategory(u.businessCategory);
    setFormCity(u.city);
    setFormState(u.state);
    setFormGstin(u.gstin);
    setFormNotes(u.ownerNotes ?? '');
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBiz) return;
    await updateUserAndBusiness(editingBiz.id, {
      businessName: formBizName.trim(),
      businessCategory: formCategory.trim(),
      city: formCity.trim(),
      state: formState.trim(),
      gstin: formGstin.trim().toUpperCase(),
      ownerNotes: formNotes.trim(),
    });
    setEditingBiz(null);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search business name, GSTIN, owner, or city..."
            className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none"
          />
        </div>

        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 focus:border-blue-600 focus:outline-none"
        >
          {categories.map((cat) => (
            <option key={cat} value={cat}>
              {cat === 'All' ? 'All Categories' : cat}
            </option>
          ))}
        </select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="No businesses found"
          description="No registered businesses match the selected filter or search text."
          actionLabel="Clear Filters"
          onAction={() => {
            setQuery('');
            setCategoryFilter('All');
          }}
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((biz) => (
            <div
              key={biz.id}
              className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="text-sm font-bold text-slate-900 truncate">
                      {biz.businessName}
                    </h3>
                    <p className="mt-0.5 text-xs text-slate-500">
                      {biz.businessCategory} · Owner: {biz.name}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 rounded-md px-2 py-0.5 text-[11px] font-semibold ${
                      biz.isBlocked
                        ? 'bg-rose-50 text-rose-700'
                        : biz.status === 'active'
                        ? 'bg-emerald-50 text-emerald-700'
                        : 'bg-amber-50 text-amber-800'
                    }`}
                  >
                    {biz.isBlocked ? 'Blocked' : biz.status === 'active' ? 'Active' : 'Deactivated'}
                  </span>
                </div>

                <div className="mt-4 space-y-2 border-t border-slate-100 pt-3 text-xs text-slate-600">
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1 text-slate-500">
                      <MapPin className="h-3.5 w-3.5" /> Location
                    </span>
                    <span className="font-medium text-slate-800">
                      {biz.city}, {biz.state}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">GSTIN</span>
                    <span className="font-mono text-[11px] font-medium text-slate-800">
                      {biz.gstin}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Joined</span>
                    <span className="font-mono text-[11px] text-slate-700">
                      {formatDateIN(biz.joinedAt)}
                    </span>
                  </div>
                </div>

                {biz.ownerNotes && (
                  <p className="mt-3 rounded-lg bg-slate-50 px-2.5 py-2 text-[11px] text-slate-600">
                    {biz.ownerNotes}
                  </p>
                )}
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3">
                <button
                  type="button"
                  onClick={() => openEdit(biz)}
                  className="inline-flex flex-1 min-h-[38px] items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  <Edit3 className="h-3.5 w-3.5" />
                  <span>Edit</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setUserStatus(biz.id, biz.status === 'active' ? 'deactivated' : 'active')
                  }
                  className={`min-h-[38px] rounded-lg px-3 text-xs font-semibold cursor-pointer ${
                    biz.status === 'active'
                      ? 'border border-amber-200 bg-amber-50 text-amber-800 hover:bg-amber-100'
                      : 'border border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                  }`}
                >
                  {biz.status === 'active' ? 'Deactivate' : 'Activate'}
                </button>
                <button
                  type="button"
                  onClick={() => setUserBlocked(biz.id, !biz.isBlocked)}
                  className={`inline-flex min-h-[38px] items-center gap-1 rounded-lg px-3 text-xs font-semibold cursor-pointer ${
                    biz.isBlocked
                      ? 'border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100'
                      : 'border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100'
                  }`}
                >
                  <ShieldOff className="h-3.5 w-3.5" />
                  <span>{biz.isBlocked ? 'Unblock' : 'Block'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={!!editingBiz}
        onClose={() => setEditingBiz(null)}
        title="Edit Business Account"
        subtitle={editingBiz ? `Owner: ${editingBiz.name}` : ''}
      >
        <form onSubmit={handleSave} className="space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-slate-700">Business Name</label>
            <input
              type="text"
              required
              value={formBizName}
              onChange={(e) => setFormBizName(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
            />
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700">Category</label>
              <input
                type="text"
                required
                value={formCategory}
                onChange={(e) => setFormCategory(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">GSTIN</label>
              <input
                type="text"
                value={formGstin}
                onChange={(e) => setFormGstin(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-xs focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700">City</label>
              <input
                type="text"
                required
                value={formCity}
                onChange={(e) => setFormCity(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">State</label>
              <input
                type="text"
                required
                value={formState}
                onChange={(e) => setFormState(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700">
              Owner Internal Notes
            </label>
            <textarea
              rows={2}
              value={formNotes}
              onChange={(e) => setFormNotes(e.target.value)}
              placeholder="Track offline deal remarks or status notes..."
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-xs focus:border-blue-600 focus:outline-none"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setEditingBiz(null)}
              className="min-h-[40px] rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[40px] rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
            >
              Save Changes
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
