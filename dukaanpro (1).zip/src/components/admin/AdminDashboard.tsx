import React, {useMemo} from 'react';
import {
  ArrowUpRight,
  Ban,
  Building2,
  CheckCircle2,
  ShieldAlert,
  UserX,
  Users,
} from 'lucide-react';
import {useApp} from '../../context/AppContext';
import {formatDateIN} from '../../utils/formatters';
import {StatCard} from '../ui/StatCard';

export type AdminSection = 'dashboard' | 'users' | 'businesses';

interface AdminDashboardProps {
  onNavigate: (section: AdminSection) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({onNavigate}) => {
  const {users, adminStats, setUserStatus, setUserBlocked} = useApp();

  const categoryBreakdown = useMemo(() => {
    const map = new Map<string, number>();
    for (const u of users) {
      map.set(u.businessCategory, (map.get(u.businessCategory) ?? 0) + 1);
    }
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, [users]);

  const restrictedUsers = useMemo(
    () => users.filter((u) => u.isBlocked || u.status === 'deactivated'),
    [users]
  );

  const recentUsers = useMemo(
    () => [...users].sort((a, b) => b.joinedAt.localeCompare(a.joinedAt)).slice(0, 5),
    [users]
  );

  return (
    <div className="space-y-6">
      {/* KPI Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Total Registered Users"
          value={String(adminStats.totalUsers)}
          subtext={`${adminStats.totalBusinesses} business accounts`}
          tone="blue"
          icon={Users}
        />
        <StatCard
          label="Active Users"
          value={String(adminStats.activeUsers)}
          subtext="Currently enabled and unblocked"
          tone="positive"
          icon={CheckCircle2}
        />
        <StatCard
          label="Deactivated Accounts"
          value={String(adminStats.deactivatedUsers)}
          subtext="Temporarily paused accounts"
          tone={adminStats.deactivatedUsers > 0 ? 'warning' : 'neutral'}
          icon={UserX}
        />
        <StatCard
          label="Blocked Users"
          value={String(adminStats.blockedUsers)}
          subtext="Access restricted by owner"
          tone={adminStats.blockedUsers > 0 ? 'danger' : 'neutral'}
          icon={ShieldAlert}
        />
      </div>

      {/* Middle Split: Business Categories + Restricted Accounts */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-6">
          <div className="flex items-center justify-between gap-3 mb-4">
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-blue-600" />
              <h2 className="text-base font-semibold text-slate-900">Business Categories</h2>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('businesses')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
            >
              <span>All Businesses</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="space-y-3.5">
            {categoryBreakdown.map(([category, count]) => {
              const pct = users.length > 0 ? Math.round((count / users.length) * 100) : 0;
              return (
                <div key={category}>
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800">{category}</span>
                    <span className="font-mono text-slate-600 tabular-nums">
                      {count} {count === 1 ? 'business' : 'businesses'} ({pct}%)
                    </span>
                  </div>
                  <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                      style={{width: `${pct}%`}}
                      className="h-full rounded-full bg-blue-600"
                    />
                  </div>
                </div>
              );
            })}
            {categoryBreakdown.length === 0 && (
              <p className="py-6 text-center text-xs text-slate-500">No businesses registered yet.</p>
            )}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-6 flex flex-col">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Ban className="h-4 w-4 text-amber-600" />
              <h2 className="text-base font-semibold text-slate-900">
                Deactivated &amp; Blocked Accounts
              </h2>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('users')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
            >
              Manage Users
            </button>
          </div>

          <div className="mt-4 divide-y divide-slate-100 flex-1">
            {restrictedUsers.map((u) => (
              <div
                key={u.id}
                className="flex flex-wrap items-center justify-between gap-3 py-3 first:pt-0 last:pb-0"
              >
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-slate-900 truncate">{u.businessName}</p>
                  <p className="text-xs text-slate-500 truncate">
                    {u.name} ·{' '}
                    <span className={u.isBlocked ? 'font-semibold text-rose-600' : 'font-medium text-amber-700'}>
                      {u.isBlocked ? 'Blocked' : 'Deactivated'}
                    </span>
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {u.isBlocked ? (
                    <button
                      type="button"
                      onClick={() => setUserBlocked(u.id, false)}
                      className="rounded-lg border border-blue-200 bg-blue-50 px-2.5 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-100 cursor-pointer"
                    >
                      Unblock
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setUserStatus(u.id, 'active')}
                      className="rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-1.5 text-xs font-semibold text-emerald-700 hover:bg-emerald-100 cursor-pointer"
                    >
                      Activate
                    </button>
                  )}
                </div>
              </div>
            ))}
            {restrictedUsers.length === 0 && (
              <p className="py-8 text-center text-xs text-slate-500">
                All registered user accounts are currently active and unblocked.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Recently Registered Users Table */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Recently Registered Users</h2>
            <p className="text-xs text-slate-500">Latest business owners on DukaanPro</p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('users')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
          >
            View All Users
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-xs font-semibold text-slate-500">
                <th className="pb-2.5 pr-4">Owner</th>
                <th className="pb-2.5 pr-4">Business</th>
                <th className="pb-2.5 pr-4">Location</th>
                <th className="pb-2.5 pr-4">Joined</th>
                <th className="pb-2.5 text-right">Access State</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recentUsers.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/70">
                  <td className="py-3 pr-4">
                    <p className="font-semibold text-slate-900">{u.name}</p>
                    <p className="text-xs text-slate-500">{u.email}</p>
                  </td>
                  <td className="py-3 pr-4">
                    <p className="font-medium text-slate-900">{u.businessName}</p>
                    <p className="text-xs text-slate-500">{u.businessCategory}</p>
                  </td>
                  <td className="py-3 pr-4 text-xs text-slate-600 whitespace-nowrap">
                    {u.city}, {u.state}
                  </td>
                  <td className="py-3 pr-4 font-mono text-xs text-slate-500 whitespace-nowrap">
                    {formatDateIN(u.joinedAt)}
                  </td>
                  <td className="py-3 text-right whitespace-nowrap">
                    <span
                      className={`inline-flex items-center rounded-md px-2 py-0.5 text-xs font-semibold ${
                        u.isBlocked
                          ? 'bg-rose-50 text-rose-700'
                          : u.status === 'active'
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-amber-50 text-amber-800'
                      }`}
                    >
                      {u.isBlocked ? 'Blocked' : u.status === 'active' ? 'Active' : 'Deactivated'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
