import React, {useMemo, useState} from 'react';
import {
  Ban,
  CheckCircle2,
  Edit3,
  Eye,
  Search,
  ShieldCheck,
  ShieldOff,
  Trash2,
  UserCheck,
  UserX,
  Users,
} from 'lucide-react';
import {useApp} from '../../context/AppContext';
import {PlatformUser} from '../../types/dukaan';
import {formatDateIN} from '../../utils/formatters';
import {EmptyState} from '../ui/EmptyState';
import {Modal} from '../ui/Modal';

type UserFilter = 'all' | 'active' | 'deactivated' | 'blocked';

export const AdminUsers: React.FC = () => {
  const {users, setUserStatus, setUserBlocked, deleteUser, updateUserAndBusiness} = useApp();

  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<UserFilter>('all');
  const [detailUser, setDetailUser] = useState<PlatformUser | null>(null);
  const [editingUser, setEditingUser] = useState<PlatformUser | null>(null);
  const [confirmDeleteUser, setConfirmDeleteUser] = useState<PlatformUser | null>(null);
  const [editError, setEditError] = useState<string | null>(null);

  // Edit form fields
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formBusinessName, setFormBusinessName] = useState('');
  const [formCategory, setFormCategory] = useState('');
  const [formCity, setFormCity] = useState('');
  const [formState, setFormState] = useState('');
  const [formGstin, setFormGstin] = useState('');
  const [formNotes, setFormNotes] = useState('');

  const filteredUsers = useMemo(() => {
    const q = query.trim().toLowerCase();
    return users.filter((u) => {
      if (filter === 'active' && (u.status !== 'active' || u.isBlocked)) return false;
      if (filter === 'deactivated' && u.status !== 'deactivated') return false;
      if (filter === 'blocked' && !u.isBlocked) return false;
      if (!q) return true;
      return (
        u.name.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.phone.toLowerCase().includes(q) ||
        u.businessName.toLowerCase().includes(q) ||
        u.city.toLowerCase().includes(q) ||
        u.gstin.toLowerCase().includes(q)
      );
    });
  }, [users, query, filter]);

  const openEditModal = (u: PlatformUser) => {
    setEditError(null);
    setEditingUser(u);
    setFormName(u.name);
    setFormEmail(u.email);
    setFormPhone(u.phone);
    setFormBusinessName(u.businessName);
    setFormCategory(u.businessCategory);
    setFormCity(u.city);
    setFormState(u.state);
    setFormGstin(u.gstin);
    setFormNotes(u.ownerNotes ?? '');
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setEditError(null);
    const res = await updateUserAndBusiness(editingUser.id, {
      name: formName.trim(),
      email: formEmail.trim(),
      phone: formPhone.trim(),
      businessName: formBusinessName.trim(),
      businessCategory: formCategory.trim(),
      city: formCity.trim(),
      state: formState.trim(),
      gstin: formGstin.trim().toUpperCase(),
      ownerNotes: formNotes.trim(),
    });
    if (!res.ok) {
      setEditError(res.error ?? 'Could not save user changes.');
      return;
    }
    setEditingUser(null);
  };

  return (
    <div className="space-y-5">
      {/* Search & Filter Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search user, phone, email, business, city, or GSTIN..."
            className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1 overflow-x-auto">
          {(
            [
              {id: 'all', label: `All (${users.length})`},
              {id: 'active', label: 'Active'},
              {id: 'deactivated', label: 'Deactivated'},
              {id: 'blocked', label: 'Blocked'},
            ] as {id: UserFilter; label: string}[]
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setFilter(tab.id)}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                filter === tab.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {filteredUsers.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No registered users match"
          description="Try clearing your search query or switching the status filter."
          actionLabel="Reset Filters"
          onAction={() => {
            setQuery('');
            setFilter('all');
          }}
        />
      ) : (
        <>
          {/* Desktop Table */}
          <div className="hidden lg:block overflow-hidden rounded-xl border border-slate-200 bg-white">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                    <th className="px-4 py-3">User &amp; Contact</th>
                    <th className="px-4 py-3">Business Details</th>
                    <th className="px-4 py-3">Account Status</th>
                    <th className="px-4 py-3">Block State</th>
                    <th className="px-4 py-3 text-right">Admin Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-slate-50/70">
                      <td className="px-4 py-3.5">
                        <p className="font-semibold text-slate-900">{user.name}</p>
                        <p className="text-xs text-slate-500">
                          {user.email} · <span className="font-mono">{user.phone}</span>
                        </p>
                      </td>
                      <td className="px-4 py-3.5">
                        <p className="font-medium text-slate-900">{user.businessName}</p>
                        <p className="text-xs text-slate-500">
                          {user.businessCategory} · {user.city}, {user.state}
                        </p>
                      </td>
                      <td className="px-4 py-3.5 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-semibold ${
                            user.status === 'active'
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-amber-50 text-amber-800'
                          }`}
                        >
                          {user.status === 'active' ? (
                            <CheckCircle2 className="h-3 w-3" />
                          ) : (
                            <UserX className="h-3 w-3" />
                          )}
                          {user.status === 'active' ? 'Active' : 'Deactivated'}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-semibold ${
                            user.isBlocked
                              ? 'bg-rose-50 text-rose-700'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {user.isBlocked ? (
                            <>
                              <Ban className="h-3 w-3" />
                              Blocked
                            </>
                          ) : (
                            <>
                              <ShieldCheck className="h-3 w-3" />
                              Allowed
                            </>
                          )}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setDetailUser(user)}
                            title="View Business Details"
                            className="inline-flex h-8 items-center gap-1 rounded-md border border-slate-200 px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            <span>View</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => openEditModal(user)}
                            title="Edit User & Business"
                            className="inline-flex h-8 items-center gap-1 rounded-md border border-slate-200 px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                          >
                            <Edit3 className="h-3.5 w-3.5" />
                            <span>Edit</span>
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setUserStatus(
                                user.id,
                                user.status === 'active' ? 'deactivated' : 'active'
                              )
                            }
                            className={`inline-flex h-8 items-center rounded-md px-2.5 text-xs font-semibold cursor-pointer ${
                              user.status === 'active'
                                ? 'border border-amber-200 bg-amber-50 text-amber-800 hover:bg-amber-100'
                                : 'border border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                            }`}
                          >
                            {user.status === 'active' ? 'Deactivate' : 'Activate'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setUserBlocked(user.id, !user.isBlocked)}
                            className={`inline-flex h-8 items-center gap-1 rounded-md px-2.5 text-xs font-semibold cursor-pointer ${
                              user.isBlocked
                                ? 'border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100'
                                : 'border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100'
                            }`}
                          >
                            {user.isBlocked ? 'Unblock' : 'Block'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteUser(user)}
                            aria-label={`Delete ${user.name}`}
                            className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100 cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile & Tablet Cards */}
          <div className="space-y-3 lg:hidden">
            {filteredUsers.map((user) => (
              <div key={user.id} className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="text-sm font-semibold text-slate-900 truncate">{user.name}</h3>
                    <p className="text-xs text-slate-500 truncate">{user.businessName}</p>
                    <p className="mt-0.5 text-[11px] text-slate-500">
                      {user.email} · {user.city}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <span
                      className={`rounded-md px-2 py-0.5 text-[11px] font-semibold ${
                        user.status === 'active'
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-amber-50 text-amber-800'
                      }`}
                    >
                      {user.status === 'active' ? 'Active' : 'Deactivated'}
                    </span>
                    {user.isBlocked && (
                      <span className="rounded-md bg-rose-50 px-2 py-0.5 text-[11px] font-semibold text-rose-700">
                        Blocked
                      </span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setDetailUser(user)}
                    className="min-h-[38px] rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                  >
                    View
                  </button>
                  <button
                    type="button"
                    onClick={() => openEditModal(user)}
                    className="min-h-[38px] rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setUserStatus(user.id, user.status === 'active' ? 'deactivated' : 'active')
                    }
                    className={`min-h-[38px] rounded-lg text-xs font-semibold cursor-pointer ${
                      user.status === 'active'
                        ? 'bg-amber-50 text-amber-800 border border-amber-200'
                        : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    }`}
                  >
                    {user.status === 'active' ? 'Deactivate' : 'Activate'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setUserBlocked(user.id, !user.isBlocked)}
                    className={`min-h-[38px] rounded-lg text-xs font-semibold cursor-pointer ${
                      user.isBlocked
                        ? 'bg-blue-50 text-blue-700 border border-blue-200'
                        : 'bg-rose-50 text-rose-700 border border-rose-200'
                    }`}
                  >
                    {user.isBlocked ? 'Unblock' : 'Block'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteUser(user)}
                    className="col-span-2 sm:col-span-1 min-h-[38px] rounded-lg border border-rose-200 bg-rose-50 text-xs font-semibold text-rose-700 cursor-pointer"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* View User & Business Details Modal */}
      <Modal
        open={!!detailUser}
        onClose={() => setDetailUser(null)}
        title={detailUser ? detailUser.businessName : ''}
        subtitle={detailUser ? `Owner: ${detailUser.name}` : ''}
      >
        {detailUser && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs">
              <div>
                <p className="text-slate-500">Owner Name</p>
                <p className="mt-0.5 font-semibold text-slate-900">{detailUser.name}</p>
              </div>
              <div>
                <p className="text-slate-500">Email</p>
                <p className="mt-0.5 font-medium text-slate-900 break-all">{detailUser.email}</p>
              </div>
              <div>
                <p className="text-slate-500">Phone</p>
                <p className="mt-0.5 font-mono font-medium text-slate-900">{detailUser.phone}</p>
              </div>
              <div>
                <p className="text-slate-500">Category</p>
                <p className="mt-0.5 font-medium text-slate-900">{detailUser.businessCategory}</p>
              </div>
              <div>
                <p className="text-slate-500">Location</p>
                <p className="mt-0.5 font-medium text-slate-900">
                  {detailUser.city}, {detailUser.state}
                </p>
              </div>
              <div>
                <p className="text-slate-500">GSTIN</p>
                <p className="mt-0.5 font-mono font-medium text-slate-900">{detailUser.gstin}</p>
              </div>
              <div>
                <p className="text-slate-500">Joined On</p>
                <p className="mt-0.5 font-mono font-medium text-slate-900">
                  {formatDateIN(detailUser.joinedAt)}
                </p>
              </div>
              <div>
                <p className="text-slate-500">Last Active</p>
                <p className="mt-0.5 font-mono font-medium text-slate-900">
                  {formatDateIN(detailUser.lastActiveAt)}
                </p>
              </div>
            </div>

            {detailUser.ownerNotes && (
              <div className="rounded-xl border border-slate-200 bg-white p-3.5 text-xs">
                <p className="font-semibold text-slate-700">Owner Deal / Internal Notes</p>
                <p className="mt-1 text-slate-600">{detailUser.ownerNotes}</p>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  const u = detailUser;
                  setDetailUser(null);
                  openEditModal(u);
                }}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-200 px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                <Edit3 className="h-3.5 w-3.5" />
                <span>Edit Details</span>
              </button>
              <button
                type="button"
                onClick={async () => {
                  const next = detailUser.status === 'active' ? 'deactivated' : 'active';
                  await setUserStatus(detailUser.id, next);
                  setDetailUser({...detailUser, status: next});
                }}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50 px-3.5 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-100 cursor-pointer"
              >
                <UserCheck className="h-3.5 w-3.5" />
                <span>{detailUser.status === 'active' ? 'Deactivate' : 'Activate'}</span>
              </button>
              <button
                type="button"
                onClick={async () => {
                  const next = !detailUser.isBlocked;
                  await setUserBlocked(detailUser.id, next);
                  setDetailUser({...detailUser, isBlocked: next});
                }}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-100 cursor-pointer"
              >
                <ShieldOff className="h-3.5 w-3.5" />
                <span>{detailUser.isBlocked ? 'Unblock User' : 'Block User'}</span>
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Edit User & Business Modal */}
      <Modal
        open={!!editingUser}
        onClose={() => setEditingUser(null)}
        title="Edit User & Business Details"
        subtitle={editingUser ? `Account ID: ${editingUser.id}` : ''}
      >
        <form onSubmit={handleSaveEdit} className="space-y-3.5">
          {editError && (
            <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-800">
              {editError}
            </div>
          )}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700">Owner Name *</label>
              <input
                type="text"
                required
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">Email *</label>
              <input
                type="email"
                required
                value={formEmail}
                onChange={(e) => setFormEmail(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700">Phone</label>
              <input
                type="tel"
                value={formPhone}
                onChange={(e) => setFormPhone(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-xs focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">Business Name *</label>
              <input
                type="text"
                required
                value={formBusinessName}
                onChange={(e) => setFormBusinessName(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700">Category</label>
              <input
                type="text"
                value={formCategory}
                onChange={(e) => setFormCategory(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">GSTIN</label>
              <input
                type="text"
                value={formGstin}
                onChange={(e) => setFormGstin(e.target.value.toUpperCase())}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-xs focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700">City</label>
              <input
                type="text"
                value={formCity}
                onChange={(e) => setFormCity(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">State</label>
              <input
                type="text"
                value={formState}
                onChange={(e) => setFormState(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700">
              Private Owner Notes (External Deal / Remarks)
            </label>
            <textarea
              rows={2}
              value={formNotes}
              onChange={(e) => setFormNotes(e.target.value)}
              placeholder="Optional notes managed by you outside the app..."
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-xs focus:border-blue-600 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setEditingUser(null)}
              className="min-h-[40px] rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[40px] rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
            >
              Save Changes
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        open={!!confirmDeleteUser}
        onClose={() => setConfirmDeleteUser(null)}
        title="Delete User & Business Account"
        subtitle="This permanently removes the user and all associated business data."
      >
        {confirmDeleteUser && (
          <div className="space-y-4">
            <p className="text-sm text-slate-600">
              Are you sure you want to permanently delete{' '}
              <strong className="font-semibold text-slate-900">{confirmDeleteUser.name}</strong> (
              {confirmDeleteUser.businessName})?
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteUser(null)}
                className="min-h-[40px] rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={async () => {
                  await deleteUser(confirmDeleteUser.id);
                  setConfirmDeleteUser(null);
                }}
                className="min-h-[40px] rounded-lg bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-700 cursor-pointer"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
