import React, {useEffect, useState} from 'react';
import {
  ArrowRight,
  BookOpenCheck,
  Building2,
  CheckCircle2,
  KeyRound,
  Lock,
  Package,
  ReceiptIndianRupee,
  ShieldCheck,
  Store,
} from 'lucide-react';
import {useApp} from '../../context/AppContext';
import {PWAInstallButton} from '../pwa/PWAInstallButton';

type AuthMode = 'business_login' | 'business_register' | 'super_admin_login';

const BUSINESS_CATEGORIES = [
  'Kirana & Groceries',
  'Apparel & Textiles',
  'Hardware & Electricals',
  'Pharmacy & Healthcare',
  'Electronics & Mobile',
  'Stationery & Books',
  'Food & Bakery',
  'Wholesale & Distribution',
];

export const AuthPortal: React.FC = () => {
  const {
    getAdminAuthStatus,
    setupAdminPasscode,
    loginAsSuperAdmin,
    loginAsBusinessUser,
    loginAsDemoBusiness,
    registerBusinessAccount,
  } = useApp();

  const [mode, setMode] = useState<AuthMode>(() => {
    if (typeof window !== 'undefined' && window.location.hash === '#admin') {
      return 'super_admin_login';
    }
    return 'business_login';
  });

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Business login
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Business registration
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regBusinessName, setRegBusinessName] = useState('');
  const [regCategory, setRegCategory] = useState(BUSINESS_CATEGORIES[0]);
  const [regCity, setRegCity] = useState('');
  const [regState, setRegState] = useState('');
  const [regGstin, setRegGstin] = useState('');

  // Super Admin login / first-run setup
  const [adminStatusLoaded, setAdminStatusLoaded] = useState(false);
  const [adminConfigured, setAdminConfigured] = useState(true);
  const [adminEmail, setAdminEmail] = useState('ahirjani91@gmail.com');
  const [adminPasscode, setAdminPasscode] = useState('');
  const [adminPasscodeConfirm, setAdminPasscodeConfirm] = useState('');

  useEffect(() => {
    setError(null);
    if (mode === 'super_admin_login') {
      setAdminStatusLoaded(false);
      getAdminAuthStatus().then((st) => {
        setAdminConfigured(st.isPasscodeConfigured);
        setAdminEmail(st.ownerEmail);
        setAdminStatusLoaded(true);
      });
    }
  }, [mode]);

  const handleBusinessLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    const res = await loginAsBusinessUser(loginEmail, loginPassword);
    setSubmitting(false);
    if (!res.ok) setError(res.error ?? 'Unable to sign in.');
  };

  const handleQuickDemoLogin = async (email: string) => {
    setError(null);
    setSubmitting(true);
    const res = await loginAsDemoBusiness(email);
    setSubmitting(false);
    if (!res.ok) setError(res.error ?? 'Unable to sign in.');
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!regName.trim() || !regEmail.trim() || !regBusinessName.trim() || !regCity.trim()) {
      setError('Please complete all required owner and business details.');
      return;
    }
    if (regPassword.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    setSubmitting(true);
    const res = await registerBusinessAccount({
      name: regName,
      email: regEmail,
      password: regPassword,
      phone: regPhone || '+91 98000 00000',
      businessName: regBusinessName,
      businessCategory: regCategory,
      city: regCity,
      state: regState || 'Maharashtra',
      gstin: regGstin,
    });
    setSubmitting(false);
    if (!res.ok) setError(res.error ?? 'Registration failed.');
  };

  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!adminConfigured) {
      if (adminPasscode.length < 6) {
        setError('Owner passcode must be at least 6 characters.');
        return;
      }
      if (adminPasscode !== adminPasscodeConfirm) {
        setError('Passcodes do not match.');
        return;
      }
      setSubmitting(true);
      const res = await setupAdminPasscode(adminEmail, adminPasscode);
      setSubmitting(false);
      if (!res.ok) setError(res.error ?? 'Failed to configure owner passcode.');
      return;
    }

    setSubmitting(true);
    const res = await loginAsSuperAdmin(adminEmail, adminPasscode);
    setSubmitting(false);
    if (!res.ok) setError(res.error ?? 'Invalid administrator credentials.');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Compact Header */}
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-700 text-white">
              <Store className="h-4 w-4" />
            </div>
            <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap">
              DukaanPro
            </span>
          </div>

          <div className="flex items-center gap-3">
            <PWAInstallButton showGuideFallback />
            <button
              type="button"
              onClick={() =>
                setMode(mode === 'super_admin_login' ? 'business_login' : 'super_admin_login')
              }
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-600 transition-colors hover:bg-slate-50 hover:text-slate-900 whitespace-nowrap cursor-pointer"
            >
              <ShieldCheck className="h-3.5 w-3.5 text-blue-600" />
              <span>{mode === 'super_admin_login' ? 'Business Portal' : 'Owner Admin'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Split Content */}
      <main className="mx-auto flex w-full max-w-7xl flex-1 items-center px-4 py-8 sm:px-6 lg:py-12">
        <div className="grid w-full grid-cols-1 gap-8 lg:grid-cols-12 lg:items-stretch">
          {/* Left Architectural Value Panel */}
          <section className="flex flex-col justify-between rounded-2xl bg-blue-700 p-6 text-white sm:p-8 lg:col-span-6 lg:p-10">
            <div>
              <p className="text-xs font-semibold tracking-wide text-blue-200">
                Built for Indian Small Businesses
              </p>
              <h1 className="mt-3 text-2xl font-bold tracking-tight text-white sm:text-4xl leading-tight">
                GST Billing, Inventory &amp; Digital Udhar Khata in One App.
              </h1>
              <p className="mt-4 max-w-xl text-sm leading-relaxed text-blue-100 sm:text-base">
                Run your shop counter on mobile or desktop. Track every rupee of Udhar and Jama,
                auto-adjust stock on every invoice, and review real-time net profit.
              </p>

              <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="rounded-xl bg-blue-800/55 p-4 border border-blue-500/30">
                  <ReceiptIndianRupee className="h-5 w-5 text-blue-200" />
                  <h2 className="mt-2.5 text-sm font-semibold text-white">
                    Fast GST Sales &amp; Purchases
                  </h2>
                  <p className="mt-1 text-xs leading-relaxed text-blue-100">
                    Create cash, UPI, or credit bills with automatic stock updates.
                  </p>
                </div>
                <div className="rounded-xl bg-blue-800/55 p-4 border border-blue-500/30">
                  <BookOpenCheck className="h-5 w-5 text-blue-200" />
                  <h2 className="mt-2.5 text-sm font-semibold text-white">
                    Udhar &amp; Jama Khata
                  </h2>
                  <p className="mt-1 text-xs leading-relaxed text-blue-100">
                    Track party-wise balances and send WhatsApp payment reminders.
                  </p>
                </div>
                <div className="rounded-xl bg-blue-800/55 p-4 border border-blue-500/30">
                  <Package className="h-5 w-5 text-blue-200" />
                  <h2 className="mt-2.5 text-sm font-semibold text-white">
                    Live Stock &amp; Reorder Alerts
                  </h2>
                  <p className="mt-1 text-xs leading-relaxed text-blue-100">
                    Know your inventory valuation and low-stock SKUs before you run out.
                  </p>
                </div>
                <div className="rounded-xl bg-blue-800/55 p-4 border border-blue-500/30">
                  <Building2 className="h-5 w-5 text-blue-200" />
                  <h2 className="mt-2.5 text-sm font-semibold text-white">
                    Profit &amp; Expense Reports
                  </h2>
                  <p className="mt-1 text-xs leading-relaxed text-blue-100">
                    Monitor rent, staff salaries, and monthly net margin in INR.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-blue-500/40 pt-5 text-xs text-blue-100">
              <span>Offline-ready Progressive Web App</span>
              <span className="font-mono">INR (₹) · GST Ready</span>
            </div>
          </section>

          {/* Right Auth Form Card */}
          <section className="flex flex-col justify-center rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 lg:col-span-6 lg:p-10">
            {mode !== 'super_admin_login' ? (
              <>
                <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
                  <button
                    type="button"
                    onClick={() => setMode('business_login')}
                    className={`flex-1 rounded-md py-2 text-xs font-semibold transition-colors cursor-pointer ${
                      mode === 'business_login'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Business Sign In
                  </button>
                  <button
                    type="button"
                    onClick={() => setMode('business_register')}
                    className={`flex-1 rounded-md py-2 text-xs font-semibold transition-colors cursor-pointer ${
                      mode === 'business_register'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Register New Dukaan
                  </button>
                </div>

                {error && (
                  <div
                    role="alert"
                    className="mt-4 rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs font-medium text-rose-800"
                  >
                    {error}
                  </div>
                )}

                {mode === 'business_login' ? (
                  <div className="mt-6">
                    <h2 className="text-xl font-bold text-slate-900">Sign in to your business</h2>
                    <p className="mt-1 text-sm text-slate-500">
                      Access your shop billing, stock, customer khata, and reports.
                    </p>

                    <form onSubmit={handleBusinessLogin} className="mt-5 space-y-4">
                      <div>
                        <label
                          htmlFor="biz-email"
                          className="block text-xs font-semibold text-slate-700"
                        >
                          Registered Business Email
                        </label>
                        <input
                          id="biz-email"
                          type="email"
                          required
                          value={loginEmail}
                          onChange={(e) => setLoginEmail(e.target.value)}
                          placeholder="owner@yourshop.in"
                          className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/15"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="biz-password"
                          className="block text-xs font-semibold text-slate-700"
                        >
                          Password
                        </label>
                        <input
                          id="biz-password"
                          type="password"
                          required
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          placeholder="Enter your password"
                          className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/15"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={submitting}
                        className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-700 disabled:opacity-60 cursor-pointer"
                      >
                        <span>{submitting ? 'Signing in...' : 'Open Business Panel'}</span>
                        <ArrowRight className="h-4 w-4" />
                      </button>
                    </form>

                    <div className="mt-6 border-t border-slate-100 pt-5">
                      <p className="text-xs font-semibold text-slate-500">
                        Quick Demo Business Accounts
                      </p>
                      <div className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                        <button
                          type="button"
                          disabled={submitting}
                          onClick={() => handleQuickDemoLogin('rajesh@sharmakirana.in')}
                          className="flex flex-col items-start rounded-xl border border-slate-200 bg-slate-50/70 p-3 text-left transition-colors hover:border-blue-300 hover:bg-blue-50/50 cursor-pointer"
                        >
                          <span className="text-xs font-semibold text-slate-900">
                            Sharma Kirana Mart
                          </span>
                          <span className="mt-0.5 text-[11px] text-slate-500">
                            Rajesh Sharma · Jaipur
                          </span>
                        </button>
                        <button
                          type="button"
                          disabled={submitting}
                          onClick={() => handleQuickDemoLogin('meena@pateltextiles.in')}
                          className="flex flex-col items-start rounded-xl border border-slate-200 bg-slate-50/70 p-3 text-left transition-colors hover:border-blue-300 hover:bg-blue-50/50 cursor-pointer"
                        >
                          <span className="text-xs font-semibold text-slate-900">
                            Patel Textiles Emporium
                          </span>
                          <span className="mt-0.5 text-[11px] text-slate-500">
                            Meena Patel · Surat
                          </span>
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleRegister} className="mt-5 space-y-3.5">
                    <div>
                      <h2 className="text-lg font-bold text-slate-900">Create Business Account</h2>
                      <p className="mt-0.5 text-xs text-slate-500">
                        Set up your shop profile for billing, inventory, and Udhar khata.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label className="block text-xs font-medium text-slate-700">
                          Owner Full Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={regName}
                          onChange={(e) => setRegName(e.target.value)}
                          placeholder="e.g. Amit Kulkarni"
                          className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-700">
                          Business / Shop Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={regBusinessName}
                          onChange={(e) => setRegBusinessName(e.target.value)}
                          placeholder="e.g. Kulkarni Super Market"
                          className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label className="block text-xs font-medium text-slate-700">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          required
                          value={regEmail}
                          onChange={(e) => setRegEmail(e.target.value)}
                          placeholder="amit@kulkarnimart.in"
                          className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-700">
                          Account Password *
                        </label>
                        <input
                          type="password"
                          required
                          minLength={6}
                          value={regPassword}
                          onChange={(e) => setRegPassword(e.target.value)}
                          placeholder="Minimum 6 characters"
                          className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label className="block text-xs font-medium text-slate-700">
                          Mobile Number
                        </label>
                        <input
                          type="tel"
                          value={regPhone}
                          onChange={(e) => setRegPhone(e.target.value)}
                          placeholder="+91 98200 11223"
                          className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-700">Category</label>
                        <select
                          value={regCategory}
                          onChange={(e) => setRegCategory(e.target.value)}
                          className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-sm focus:border-blue-600 focus:outline-none"
                        >
                          {BUSINESS_CATEGORIES.map((c) => (
                            <option key={c} value={c}>
                              {c}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-700">City *</label>
                        <input
                          type="text"
                          required
                          value={regCity}
                          onChange={(e) => setRegCity(e.target.value)}
                          placeholder="Nagpur"
                          className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-700">State</label>
                        <input
                          type="text"
                          value={regState}
                          onChange={(e) => setRegState(e.target.value)}
                          placeholder="Maharashtra"
                          className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-700">
                          GSTIN (Optional)
                        </label>
                        <input
                          type="text"
                          value={regGstin}
                          onChange={(e) => setRegGstin(e.target.value.toUpperCase())}
                          placeholder="27AABCU9603R1ZM"
                          className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-xs focus:border-blue-600 focus:outline-none"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={submitting}
                      className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-700 disabled:opacity-60 cursor-pointer"
                    >
                      <CheckCircle2 className="h-4 w-4" />
                      <span>{submitting ? 'Creating Account...' : 'Create Business Account'}</span>
                    </button>
                  </form>
                )}
              </>
            ) : (
              /* Super Admin Dedicated Portal Login / First-Run Owner Setup */
              <div>
                <div className="flex items-center gap-2 text-blue-700">
                  <ShieldCheck className="h-5 w-5" />
                  <span className="text-xs font-semibold">Restricted Owner Console</span>
                </div>

                {!adminStatusLoaded ? (
                  <div className="py-12 text-center text-sm text-slate-500">
                    Checking owner access status...
                  </div>
                ) : !adminConfigured ? (
                  <>
                    <h2 className="mt-2 text-xl font-bold text-slate-900">
                      Set Up Owner Admin Passcode
                    </h2>
                    <p className="mt-1 text-sm text-slate-500">
                      Create the Super Admin passcode for <span className="font-semibold text-slate-700">{adminEmail}</span>. This one-time setup locks automatically once saved.
                    </p>

                    {error && (
                      <div
                        role="alert"
                        className="mt-4 rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs font-medium text-rose-800"
                      >
                        {error}
                      </div>
                    )}

                    <form onSubmit={handleAdminSubmit} className="mt-5 space-y-4">
                      <div>
                        <label
                          htmlFor="setup-admin-email"
                          className="block text-xs font-semibold text-slate-700"
                        >
                          Designated Owner Email
                        </label>
                        <input
                          id="setup-admin-email"
                          type="email"
                          required
                          value={adminEmail}
                          onChange={(e) => setAdminEmail(e.target.value)}
                          className="mt-1.5 w-full rounded-lg border border-slate-200 px-3.5 py-2.5 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/15"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="setup-admin-passcode"
                          className="block text-xs font-semibold text-slate-700"
                        >
                          Choose Owner Passcode (min 6 characters)
                        </label>
                        <div className="relative mt-1.5">
                          <input
                            id="setup-admin-passcode"
                            type="password"
                            required
                            minLength={6}
                            value={adminPasscode}
                            onChange={(e) => setAdminPasscode(e.target.value)}
                            placeholder="Create a strong passcode"
                            className="w-full rounded-lg border border-slate-200 px-3.5 py-2.5 pr-10 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/15"
                          />
                          <KeyRound className="pointer-events-none absolute right-3 top-3 h-4 w-4 text-slate-400" />
                        </div>
                      </div>
                      <div>
                        <label
                          htmlFor="setup-admin-confirm"
                          className="block text-xs font-semibold text-slate-700"
                        >
                          Confirm Passcode
                        </label>
                        <input
                          id="setup-admin-confirm"
                          type="password"
                          required
                          minLength={6}
                          value={adminPasscodeConfirm}
                          onChange={(e) => setAdminPasscodeConfirm(e.target.value)}
                          placeholder="Re-enter passcode"
                          className="mt-1.5 w-full rounded-lg border border-slate-200 px-3.5 py-2.5 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/15"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={submitting}
                        className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-800 disabled:opacity-60 cursor-pointer"
                      >
                        <span>{submitting ? 'Securing Console...' : 'Save Passcode & Enter Admin Panel'}</span>
                        <ArrowRight className="h-4 w-4" />
                      </button>
                    </form>
                  </>
                ) : (
                  <>
                    <h2 className="mt-2 text-xl font-bold text-slate-900">
                      DukaanPro Super Admin Login
                    </h2>
                    <p className="mt-1 text-sm text-slate-500">
                      Owner-only access to manage registered users and business accounts.
                    </p>

                    {error && (
                      <div
                        role="alert"
                        className="mt-4 rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs font-medium text-rose-800"
                      >
                        {error}
                      </div>
                    )}

                    <form onSubmit={handleAdminSubmit} className="mt-5 space-y-4">
                      <div>
                        <label
                          htmlFor="admin-email"
                          className="block text-xs font-semibold text-slate-700"
                        >
                          Owner Email
                        </label>
                        <input
                          id="admin-email"
                          type="email"
                          required
                          value={adminEmail}
                          onChange={(e) => setAdminEmail(e.target.value)}
                          className="mt-1.5 w-full rounded-lg border border-slate-200 px-3.5 py-2.5 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/15"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="admin-passcode"
                          className="block text-xs font-semibold text-slate-700"
                        >
                          Owner Passcode
                        </label>
                        <div className="relative mt-1.5">
                          <input
                            id="admin-passcode"
                            type="password"
                            required
                            value={adminPasscode}
                            onChange={(e) => setAdminPasscode(e.target.value)}
                            placeholder="Enter owner passcode"
                            className="w-full rounded-lg border border-slate-200 px-3.5 py-2.5 pr-10 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/15"
                          />
                          <Lock className="pointer-events-none absolute right-3 top-3 h-4 w-4 text-slate-400" />
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={submitting}
                        className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-800 disabled:opacity-60 cursor-pointer"
                      >
                        <span>{submitting ? 'Verifying...' : 'Enter Super Admin Panel'}</span>
                        <ArrowRight className="h-4 w-4" />
                      </button>
                    </form>
                  </>
                )}

                <div className="mt-5 flex items-center justify-between border-t border-slate-100 pt-4 text-xs text-slate-500">
                  <span>Role-verified backend session</span>
                  <button
                    type="button"
                    onClick={() => setMode('business_login')}
                    className="font-semibold text-blue-600 hover:underline cursor-pointer"
                  >
                    Back to Business Sign In
                  </button>
                </div>
              </div>
            )}
          </section>
        </div>
      </main>
    </div>
  );
};
