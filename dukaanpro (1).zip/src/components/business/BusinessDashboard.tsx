import React from 'react';
import {
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  BookOpenCheck,
  IndianRupee,
  Package,
  Plus,
  ReceiptIndianRupee,
  TrendingUp,
} from 'lucide-react';
import {useApp} from '../../context/AppContext';
import {formatDateIN, formatINR} from '../../utils/formatters';
import {ChartBarPoint, MiniBarChart} from '../ui/MiniBarChart';
import {StatCard} from '../ui/StatCard';

export type BusinessSection =
  | 'dashboard'
  | 'products'
  | 'trades'
  | 'customers'
  | 'ledger'
  | 'reports';

interface BusinessDashboardProps {
  onNavigate: (section: BusinessSection) => void;
}

export const BusinessDashboard: React.FC<BusinessDashboardProps> = ({onNavigate}) => {
  const {
    activeBusinessUser,
    products,
    transactions,
    customers,
    ledgerEntries,
    expenses,
    adjustProductStock,
  } = useApp();

  const sales = transactions.filter((t) => t.type === 'sale');
  const purchases = transactions.filter((t) => t.type === 'purchase');

  const totalSales = sales.reduce((s, t) => s + t.totalAmount, 0);
  const totalPurchases = purchases.reduce((s, t) => s + t.totalAmount, 0);
  const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);

  // Calculate COGS based on product purchase price for sold items when available
  const estimatedCOGS = sales.reduce((sum, sale) => {
    const saleCost = sale.items.reduce((itemSum, item) => {
      const prod = products.find((p) => p.id === item.productId);
      const unitCost = prod ? prod.purchasePrice : item.rate * 0.82;
      return itemSum + unitCost * item.qty;
    }, 0);
    return sum + saleCost;
  }, 0);

  const grossProfit = Math.round(totalSales - estimatedCOGS);
  const netProfit = Math.round(grossProfit - totalExpenses);

  // Total pending Udhar across all customers
  const totalUdharReceivable = customers.reduce((sum, c) => {
    const entries = ledgerEntries.filter((l) => l.customerId === c.id);
    const udhar = entries
      .filter((l) => l.type === 'udhar')
      .reduce((s, l) => s + l.amount, 0);
    const jama = entries
      .filter((l) => l.type === 'jama')
      .reduce((s, l) => s + l.amount, 0);
    return sum + Math.max(0, c.openingBalance + udhar - jama);
  }, 0);

  const lowStockProducts = products.filter((p) => p.stock <= p.minStock);

  const chartData: ChartBarPoint[] = [
    {label: '15 Nov', primary: 14200, secondary: 6200},
    {label: '16 Nov', primary: 11800, secondary: 4100},
    {label: '17 Nov', primary: 16400, secondary: 5300},
    {label: '18 Nov', primary: 13900, secondary: 7400},
    {label: '19 Nov', primary: 19200, secondary: 4800},
    {label: '20 Nov', primary: Math.max(11856, Math.round(totalSales * 0.35)), secondary: 5200},
  ];

  return (
    <div className="space-y-6">
      {/* Welcome & Quick Action Strip */}
      <div className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5">
        <div className="min-w-0">
          <h2 className="text-base font-bold text-slate-900 truncate">
            Namaste, {activeBusinessUser?.name ?? 'Business Owner'}
          </h2>
          <p className="mt-0.5 text-xs text-slate-500 truncate">
            {activeBusinessUser?.businessName} · {activeBusinessUser?.city},{' '}
            {activeBusinessUser?.state}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => onNavigate('trades')}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>New Sale</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('ledger')}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50 px-3.5 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-100 transition-colors cursor-pointer whitespace-nowrap"
          >
            <BookOpenCheck className="h-3.5 w-3.5" />
            <span>Udhar / Jama</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('products')}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Package className="h-3.5 w-3.5" />
            <span>Add Stock</span>
          </button>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Total Sales"
          value={formatINR(totalSales)}
          subtext={`${sales.length} invoices recorded`}
          tone="blue"
          icon={ReceiptIndianRupee}
        />
        <StatCard
          label="Total Purchases"
          value={formatINR(totalPurchases)}
          subtext={`${purchases.length} supplier bills`}
          tone="neutral"
          icon={ArrowDownLeft}
        />
        <StatCard
          label="Udhar Receivable"
          value={formatINR(totalUdharReceivable)}
          subtext="Pending from credit customers"
          tone={totalUdharReceivable > 0 ? 'warning' : 'positive'}
          icon={BookOpenCheck}
        />
        <StatCard
          label="Estimated Net Profit"
          value={formatINR(netProfit)}
          subtext={`After ${formatINR(totalExpenses)} shop expenses`}
          tone={netProfit >= 0 ? 'positive' : 'danger'}
          icon={TrendingUp}
        />
      </div>

      {/* Chart & Low Stock Split */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-7">
          <div className="flex items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="text-base font-semibold text-slate-900">Sales vs Outflow</h3>
              <p className="text-xs text-slate-500">Daily billing vs purchases &amp; expenses</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('reports')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
            >
              <span>Profit Report</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>
          <MiniBarChart
            data={chartData}
            primaryLabel="Sales (₹)"
            secondaryLabel="Outflow (₹)"
            primaryColorClass="bg-blue-600"
            secondaryColorClass="bg-slate-300"
          />
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-5 flex flex-col">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <h3 className="text-base font-semibold text-slate-900">Low Stock Alerts</h3>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('products')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
            >
              Inventory
            </button>
          </div>

          <div className="mt-4 divide-y divide-slate-100 flex-1">
            {lowStockProducts.slice(0, 4).map((prod) => (
              <div
                key={prod.id}
                className="flex items-center justify-between gap-3 py-3 first:pt-0 last:pb-0"
              >
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-slate-900 truncate">{prod.name}</p>
                  <p className="text-xs text-slate-500">
                    In stock:{' '}
                    <span className="font-mono font-semibold text-rose-600">
                      {prod.stock} {prod.unit}
                    </span>{' '}
                    · Min {prod.minStock}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => adjustProductStock(prod.id, 10)}
                  className="shrink-0 rounded-lg border border-blue-200 bg-blue-50 px-2.5 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-100 transition-colors cursor-pointer"
                >
                  +10 {prod.unit}
                </button>
              </div>
            ))}
            {lowStockProducts.length === 0 && (
              <p className="py-8 text-center text-xs text-slate-500">
                All products are well-stocked above minimum thresholds.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Recent Vouchers */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <IndianRupee className="h-4 w-4 text-blue-600" />
            <h3 className="text-base font-semibold text-slate-900">Recent Sales &amp; Purchases</h3>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('trades')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
          >
            View All Vouchers
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-xs font-semibold text-slate-500">
                <th className="pb-2.5 pr-4">Voucher</th>
                <th className="pb-2.5 pr-4">Type</th>
                <th className="pb-2.5 pr-4">Party</th>
                <th className="pb-2.5 pr-4">Mode</th>
                <th className="pb-2.5 pr-4">Date</th>
                <th className="pb-2.5 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {transactions.slice(0, 5).map((trx) => (
                <tr key={trx.id} className="hover:bg-slate-50/70">
                  <td className="py-3 pr-4 font-mono text-xs font-medium text-slate-700 whitespace-nowrap">
                    {trx.voucherNo}
                  </td>
                  <td className="py-3 pr-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center rounded-md px-2 py-0.5 text-xs font-semibold ${
                        trx.type === 'sale'
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-blue-50 text-blue-700'
                      }`}
                    >
                      {trx.type === 'sale' ? 'Sale' : 'Purchase'}
                    </span>
                  </td>
                  <td className="py-3 pr-4 font-medium text-slate-900 truncate max-w-[200px]">
                    {trx.partyName}
                  </td>
                  <td className="py-3 pr-4 text-xs text-slate-600 whitespace-nowrap">
                    {trx.paymentMode}
                  </td>
                  <td className="py-3 pr-4 font-mono text-xs text-slate-500 whitespace-nowrap">
                    {formatDateIN(trx.date)}
                  </td>
                  <td className="py-3 text-right font-mono text-sm font-bold text-slate-900 tabular-nums whitespace-nowrap">
                    {formatINR(trx.totalAmount)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
