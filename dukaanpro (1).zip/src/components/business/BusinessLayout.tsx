import React, {useState} from 'react';
import {
  BarChart3,
  BookOpenCheck,
  LayoutDashboard,
  LogOut,
  Menu,
  Package,
  ReceiptIndianRupee,
  Store,
  Users,
  X,
} from 'lucide-react';
import {useApp} from '../../context/AppContext';
import {PWAInstallButton} from '../pwa/PWAInstallButton';
import {BusinessDashboard, BusinessSection} from './BusinessDashboard';
import {CustomersDirectory} from './CustomersDirectory';
import {ExpensesReports} from './ExpensesReports';
import {ProductsInventory} from './ProductsInventory';
import {SalesPurchases} from './SalesPurchases';
import {UdharJamaLedger} from './UdharJamaLedger';

const NAV_ITEMS: {
  id: BusinessSection;
  label: string;
  shortLabel: string;
  icon: React.ComponentType<{className?: string}>;
}[] = [
  {id: 'dashboard', label: 'Dashboard', shortLabel: 'Home', icon: LayoutDashboard},
  {id: 'products', label: 'Products & Stock', shortLabel: 'Stock', icon: Package},
  {id: 'trades', label: 'Sales & Purchases', shortLabel: 'Billing', icon: ReceiptIndianRupee},
  {id: 'customers', label: 'Customers', shortLabel: 'Parties', icon: Users},
  {id: 'ledger', label: 'Udhar & Jama', shortLabel: 'Khata', icon: BookOpenCheck},
  {id: 'reports', label: 'Expenses & Reports', shortLabel: 'Reports', icon: BarChart3},
];

const MOBILE_PRIMARY_TABS: BusinessSection[] = ['dashboard', 'trades', 'ledger', 'products'];

const SECTION_META: Record<BusinessSection, {title: string; subtitle: string}> = {
  dashboard: {
    title: 'Business Dashboard',
    subtitle: 'Daily sales, inventory alerts, Udhar dues, and net profit',
  },
  products: {
    title: 'Products & Inventory',
    subtitle: 'Manage SKUs, GST rates, stock counts, and inventory valuation',
  },
  trades: {
    title: 'Sales & Purchases',
    subtitle: 'Create GST invoices, record supplier bills, and sync stock automatically',
  },
  customers: {
    title: 'Customers Directory',
    subtitle: 'Manage buyer profiles, GSTIN details, and credit balances',
  },
  ledger: {
    title: 'Udhar & Jama Ledger',
    subtitle: 'Track credit given, payments received, and WhatsApp reminders',
  },
  reports: {
    title: 'Expenses & Profit Reports',
    subtitle: 'Shop overhead register, GST summary, and Profit & Loss statement',
  },
};

export const BusinessLayout: React.FC = () => {
  const {activeBusinessUser, logout} = useApp();
  const [section, setSection] = useState<BusinessSection>('dashboard');
  const [focusedCustomerId, setFocusedCustomerId] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const meta = SECTION_META[section];

  const handleOpenKhata = (customerId: string) => {
    setFocusedCustomerId(customerId);
    setSection('ledger');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col lg:flex-row">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 border-r border-slate-200 bg-white">
        <div className="flex h-16 items-center gap-2.5 border-b border-slate-100 px-5">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-600 text-white">
            <Store className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <span className="block text-sm font-bold tracking-tight text-slate-900 truncate">
              DukaanPro
            </span>
            <span className="block text-[11px] font-medium text-slate-500 truncate">
              {activeBusinessUser?.businessName ?? 'Business Workspace'}
            </span>
          </div>
        </div>

        <nav className="flex-1 space-y-1 px-3 py-4" aria-label="Business Navigation">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = section === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setSection(item.id)}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors cursor-pointer ${
                  active
                    ? 'bg-blue-50 text-blue-700 font-semibold'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <Icon className={`h-4 w-4 shrink-0 ${active ? 'text-blue-700' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-100 p-4 space-y-3">
          {activeBusinessUser && (
            <div className="rounded-lg bg-slate-50 px-3 py-2.5 text-xs">
              <p className="font-semibold text-slate-900 truncate">{activeBusinessUser.name}</p>
              <p className="mt-0.5 text-[11px] text-slate-500 truncate">
                {activeBusinessUser.businessCategory} · {activeBusinessUser.city}
              </p>
            </div>
          )}
          <button
            type="button"
            onClick={logout}
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content Shell */}
      <div className="flex-1 lg:pl-64 flex flex-col min-h-screen pb-20 lg:pb-0">
        {/* Top App Bar */}
        <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-xs">
          <div className="mx-auto flex h-14 lg:h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-600 text-white lg:hidden">
                <Store className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <h1 className="text-base lg:text-lg font-bold text-slate-900 truncate">
                  {meta.title}
                </h1>
                <p className="hidden sm:block text-xs text-slate-500 truncate">{meta.subtitle}</p>
              </div>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <PWAInstallButton compact showGuideFallback />
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                aria-label="Open menu"
                className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-700 lg:hidden cursor-pointer"
              >
                <Menu className="h-4 w-4" />
              </button>
            </div>
          </div>
        </header>

        <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-5 sm:px-6 lg:py-6">
          {section === 'dashboard' && <BusinessDashboard onNavigate={setSection} />}
          {section === 'products' && <ProductsInventory />}
          {section === 'trades' && <SalesPurchases />}
          {section === 'customers' && <CustomersDirectory onOpenKhata={handleOpenKhata} />}
          {section === 'ledger' && <UdharJamaLedger initialCustomerId={focusedCustomerId} />}
          {section === 'reports' && <ExpensesReports />}
        </main>
      </div>

      {/* Mobile Bottom Thumb Navigation */}
      <nav
        aria-label="Mobile Business Navigation"
        className="fixed bottom-0 left-0 right-0 z-40 grid h-16 grid-cols-5 border-t border-slate-200 bg-white/95 backdrop-blur-md pb-safe lg:hidden"
      >
        {MOBILE_PRIMARY_TABS.map((tabId) => {
          const item = NAV_ITEMS.find((n) => n.id === tabId)!;
          const Icon = item.icon;
          const active = section === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setSection(item.id)}
              className={`flex min-h-[44px] flex-col items-center justify-center gap-1 text-[10px] font-medium cursor-pointer ${
                active ? 'text-blue-700 font-semibold' : 'text-slate-500'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="truncate">{item.shortLabel}</span>
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => setMobileMenuOpen(true)}
          className={`flex min-h-[44px] flex-col items-center justify-center gap-1 text-[10px] font-medium cursor-pointer ${
            section === 'customers' || section === 'reports'
              ? 'text-blue-700 font-semibold'
              : 'text-slate-500'
          }`}
        >
          <Menu className="h-5 w-5" />
          <span>More</span>
        </button>
      </nav>

      {/* Mobile Slide-Over Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true">
          <div
            className="fixed inset-0 bg-slate-900/45 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="fixed inset-y-0 right-0 w-72 bg-white p-5 shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="min-w-0">
                  <p className="text-sm font-bold text-slate-900 truncate">
                    {activeBusinessUser?.businessName}
                  </p>
                  <p className="text-xs text-slate-500 truncate">
                    {activeBusinessUser?.name} · {activeBusinessUser?.city}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  aria-label="Close menu"
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="mt-4 space-y-1">
                {NAV_ITEMS.map((item) => {
                  const Icon = item.icon;
                  const active = section === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setSection(item.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium cursor-pointer ${
                        active ? 'bg-blue-50 text-blue-700 font-semibold' : 'text-slate-700'
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <button
              type="button"
              onClick={logout}
              className="flex w-full min-h-[44px] items-center justify-center gap-2 rounded-lg border border-slate-200 px-3 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <LogOut className="h-4 w-4" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
