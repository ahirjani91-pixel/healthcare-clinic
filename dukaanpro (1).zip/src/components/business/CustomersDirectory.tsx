import React, {useMemo, useState} from 'react';
import {BookOpenCheck, Edit3, Phone, Plus, Search, Users} from 'lucide-react';
import {useApp} from '../../context/AppContext';
import {Customer} from '../../types/dukaan';
import {formatINR} from '../../utils/formatters';
import {EmptyState} from '../ui/EmptyState';
import {Modal} from '../ui/Modal';

interface CustomersDirectoryProps {
  onOpenKhata: (customerId: string) => void;
}

export const CustomersDirectory: React.FC<CustomersDirectoryProps> = ({onOpenKhata}) => {
  const {customers, ledgerEntries, addCustomer, updateCustomer} = useApp();
  const [query, setQuery] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Customer | null>(null);

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [gstin, setGstin] = useState('');
  const [openingBalance, setOpeningBalance] = useState(0);

  const customerBalances = useMemo(() => {
    const map = new Map<string, number>();
    for (const c of customers) {
      const entries = ledgerEntries.filter((l) => l.customerId === c.id);
      const udhar = entries.filter((l) => l.type === 'udhar').reduce((s, l) => s + l.amount, 0);
      const jama = entries.filter((l) => l.type === 'jama').reduce((s, l) => s + l.amount, 0);
      map.set(c.id, c.openingBalance + udhar - jama);
    }
    return map;
  }, [customers, ledgerEntries]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return customers.filter((c) => {
      if (!q) return true;
      return (
        c.name.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        c.city.toLowerCase().includes(q)
      );
    });
  }, [customers, query]);

  const openAdd = () => {
    setEditing(null);
    setName('');
    setPhone('+91 ');
    setCity('');
    setGstin('');
    setOpeningBalance(0);
    setModalOpen(true);
  };

  const openEdit = (c: Customer) => {
    setEditing(c);
    setName(c.name);
    setPhone(c.phone);
    setCity(c.city);
    setGstin(c.gstin ?? '');
    setOpeningBalance(c.openingBalance);
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const payload = {
      name: name.trim(),
      phone: phone.trim() || '+91 98000 00000',
      city: city.trim() || 'Local',
      gstin: gstin.trim().toUpperCase() || undefined,
      openingBalance: Number(openingBalance) || 0,
    };
    if (editing) {
      updateCustomer(editing.id, payload);
    } else {
      addCustomer(payload);
    }
    setModalOpen(false);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search customer name, phone, or city..."
            className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm focus:border-blue-600 focus:outline-none"
          />
        </div>

        <button
          type="button"
          onClick={openAdd}
          className="inline-flex min-h-[40px] items-center justify-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          <span>Add Customer</span>
        </button>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No customers found"
          description="Add your regular buyers or credit customers to manage bills and Khata."
          actionLabel="Add Customer"
          onAction={openAdd}
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((c) => {
            const balance = customerBalances.get(c.id) ?? 0;
            return (
              <div
                key={c.id}
                className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5"
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h3 className="text-sm font-bold text-slate-900 truncate">{c.name}</h3>
                      <p className="mt-0.5 inline-flex items-center gap-1 text-xs text-slate-500">
                        <Phone className="h-3 w-3" />
                        <span className="font-mono">{c.phone}</span>
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => openEdit(c)}
                      aria-label={`Edit ${c.name}`}
                      className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-50 cursor-pointer"
                    >
                      <Edit3 className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3 text-xs">
                    <span className="text-slate-500">
                      {c.city} {c.gstin ? `· ${c.gstin}` : ''}
                    </span>
                    <span
                      className={`font-mono text-sm font-bold tabular-nums ${
                        balance > 0
                          ? 'text-rose-600'
                          : balance < 0
                          ? 'text-emerald-700'
                          : 'text-slate-500'
                      }`}
                    >
                      {balance > 0
                        ? `${formatINR(balance)} Due`
                        : balance < 0
                        ? `${formatINR(Math.abs(balance))} Adv`
                        : 'Settled'}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onOpenKhata(c.id)}
                  className="mt-4 inline-flex min-h-[40px] w-full items-center justify-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50 px-3 text-xs font-semibold text-blue-700 hover:bg-blue-100 transition-colors cursor-pointer"
                >
                  <BookOpenCheck className="h-3.5 w-3.5" />
                  <span>Open Udhar / Jama Khata</span>
                </button>
              </div>
            );
          })}
        </div>
      )}

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Customer' : 'Add New Customer'}
        subtitle="Save buyer contact details and opening Udhar balance"
      >
        <form onSubmit={handleSave} className="space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-slate-700">Customer Name *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Anand General Store"
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700">Phone Number *</label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-xs focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">City</label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Jaipur"
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700">GSTIN (Optional)</label>
              <input
                type="text"
                value={gstin}
                onChange={(e) => setGstin(e.target.value.toUpperCase())}
                placeholder="08AABCU9603R1ZM"
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-xs focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">
                Opening Udhar (₹)
              </label>
              <input
                type="number"
                value={openingBalance}
                onChange={(e) => setOpeningBalance(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="min-h-[40px] rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[40px] rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
            >
              {editing ? 'Update Customer' : 'Save Customer'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
