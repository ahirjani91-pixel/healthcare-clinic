import React, {useMemo, useState} from 'react';
import {
  Download,
  IndianRupee,
  Plus,
  ReceiptText,
  Trash2,
  TrendingUp,
} from 'lucide-react';
import {useApp} from '../../context/AppContext';
import {ExpenseCategory} from '../../types/dukaan';
import {exportToCSV, formatDateIN, formatINR} from '../../utils/formatters';
import {Modal} from '../ui/Modal';
import {StatCard} from '../ui/StatCard';

const EXPENSE_CATEGORIES: ExpenseCategory[] = [
  'Rent',
  'Electricity & Internet',
  'Staff Salary',
  'Transport & Freight',
  'Packaging',
  'Shop Maintenance',
  'Other',
];

export const ExpensesReports: React.FC = () => {
  const {transactions, products, expenses, addExpense, deleteExpense} = useApp();
  const [modalOpen, setModalOpen] = useState(false);

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('Rent');
  const [amount, setAmount] = useState<number>(1000);
  const [paymentMode, setPaymentMode] = useState<'Cash' | 'UPI' | 'Bank Transfer'>('UPI');
  const [vendor, setVendor] = useState('');

  const sales = transactions.filter((t) => t.type === 'sale');
  const purchases = transactions.filter((t) => t.type === 'purchase');

  const grossSales = sales.reduce((s, t) => s + t.totalAmount, 0);
  const gstOutput = sales.reduce((s, t) => s + t.gstAmount, 0);
  const gstInput = purchases.reduce((s, t) => s + t.gstAmount, 0);
  const netSalesExGst = grossSales - gstOutput;

  const estimatedCOGS = Math.round(
    sales.reduce((sum, sale) => {
      const cost = sale.items.reduce((iSum, item) => {
        const prod = products.find((p) => p.id === item.productId);
        return iSum + (prod ? prod.purchasePrice : item.rate * 0.82) * item.qty;
      }, 0);
      return sum + cost;
    }, 0)
  );

  const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);
  const grossMargin = netSalesExGst - estimatedCOGS;
  const netProfit = grossMargin - totalExpenses;
  const profitMarginPct =
    netSalesExGst > 0 ? Math.round((netProfit / netSalesExGst) * 100) : 0;

  const categoryBreakdown = useMemo(() => {
    const map = new Map<string, number>();
    for (const e of expenses) {
      map.set(e.category, (map.get(e.category) ?? 0) + e.amount);
    }
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, [expenses]);

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || amount <= 0) return;
    addExpense({
      title: title.trim(),
      category,
      amount: Number(amount),
      paymentMode,
      date: '2026-11-20',
      vendor: vendor.trim() || undefined,
    });
    setTitle('');
    setVendor('');
    setAmount(1000);
    setModalOpen(false);
  };

  const handleExportPL = () => {
    exportToCSV('dukaanpro-profit-loss-report.csv', [
      {LineItem: 'Gross Sales (Incl. GST)', AmountINR: grossSales},
      {LineItem: 'Output GST Collected', AmountINR: gstOutput},
      {LineItem: 'Net Sales (Excl. GST)', AmountINR: netSalesExGst},
      {LineItem: 'Estimated Cost of Goods Sold (COGS)', AmountINR: estimatedCOGS},
      {LineItem: 'Gross Trading Profit', AmountINR: grossMargin},
      {LineItem: 'Total Shop Operating Expenses', AmountINR: totalExpenses},
      {LineItem: 'Net Business Profit', AmountINR: netProfit},
      {LineItem: 'Input Tax Credit (Purchase GST)', AmountINR: gstInput},
    ]);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Net Sales (Excl. GST)"
          value={formatINR(netSalesExGst)}
          subtext={`Gross billed ${formatINR(grossSales)}`}
          tone="blue"
          icon={IndianRupee}
        />
        <StatCard
          label="Gross Trading Profit"
          value={formatINR(grossMargin)}
          subtext={`After ${formatINR(estimatedCOGS)} COGS`}
          tone="neutral"
          icon={TrendingUp}
        />
        <StatCard
          label="Total Shop Expenses"
          value={formatINR(totalExpenses)}
          subtext={`${expenses.length} recorded vouchers`}
          tone="warning"
          icon={ReceiptText}
        />
        <StatCard
          label="Net Profit"
          value={formatINR(netProfit)}
          subtext={`${profitMarginPct}% net margin`}
          tone={netProfit >= 0 ? 'positive' : 'danger'}
          icon={TrendingUp}
        />
      </div>

      {/* Profit & Loss Statement + Category Breakdown */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-7">
          <div className="flex items-center justify-between gap-3 border-b border-slate-100 pb-3.5">
            <div>
              <h2 className="text-base font-bold text-slate-900">Profit &amp; Loss Summary</h2>
              <p className="text-xs text-slate-500">Current period trading &amp; GST overview</p>
            </div>
            <button
              type="button"
              onClick={handleExportPL}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export P&amp;L</span>
            </button>
          </div>

          <div className="mt-4 space-y-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-slate-600">Gross Sales Revenue</span>
              <span className="font-mono font-semibold text-slate-900 tabular-nums">
                {formatINR(grossSales)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-600">Less: Output GST Collected</span>
              <span className="font-mono text-slate-600 tabular-nums">- {formatINR(gstOutput)}</span>
            </div>
            <div className="flex items-center justify-between border-t border-slate-100 pt-2.5">
              <span className="font-semibold text-slate-800">Net Sales</span>
              <span className="font-mono font-bold text-slate-900 tabular-nums">
                {formatINR(netSalesExGst)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-600">Less: Cost of Goods Sold (COGS)</span>
              <span className="font-mono text-slate-600 tabular-nums">
                - {formatINR(estimatedCOGS)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-600">Less: Operating Expenses</span>
              <span className="font-mono text-rose-600 tabular-nums">
                - {formatINR(totalExpenses)}
              </span>
            </div>
            <div className="flex items-center justify-between border-t border-slate-200 pt-3">
              <span className="text-base font-bold text-slate-900">Net Business Profit</span>
              <span
                className={`font-mono text-lg font-bold tabular-nums ${
                  netProfit >= 0 ? 'text-emerald-700' : 'text-rose-600'
                }`}
              >
                {formatINR(netProfit)}
              </span>
            </div>
            <div className="mt-3 rounded-lg bg-slate-50 px-3.5 py-2.5 flex items-center justify-between text-xs">
              <span className="text-slate-600">Net GST Payable (Output - Input ITC)</span>
              <span className="font-mono font-semibold text-blue-700 tabular-nums">
                {formatINR(Math.max(0, gstOutput - gstInput))}
              </span>
            </div>
          </div>
        </div>

        {/* Expense Breakdown */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-5">
          <h2 className="text-base font-bold text-slate-900">Expense Breakdown</h2>
          <p className="text-xs text-slate-500">Where shop overhead is going</p>

          <div className="mt-4 space-y-3.5">
            {categoryBreakdown.map(([cat, val]) => {
              const pct = totalExpenses > 0 ? Math.round((val / totalExpenses) * 100) : 0;
              return (
                <div key={cat}>
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800">{cat}</span>
                    <span className="font-mono text-slate-700 tabular-nums">
                      {formatINR(val)} ({pct}%)
                    </span>
                  </div>
                  <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                      style={{width: `${pct}%`}}
                      className="h-full rounded-full bg-blue-600"
                    />
                  </div>
                </div>
              );
            })}
            {categoryBreakdown.length === 0 && (
              <p className="py-6 text-center text-xs text-slate-500">No expenses logged yet.</p>
            )}
          </div>
        </div>
      </div>

      {/* Expense Ledger List */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">Shop Expenses Register</h2>
            <p className="text-xs text-slate-500">Rent, salaries, electricity, transport &amp; petty cash</p>
          </div>
          <button
            type="button"
            onClick={() => setModalOpen(true)}
            className="inline-flex min-h-[40px] items-center justify-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Add Expense</span>
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {expenses.map((exp) => (
            <div key={exp.id} className="flex items-center justify-between gap-3 py-3">
              <div className="min-w-0">
                <p className="text-sm font-semibold text-slate-900 truncate">{exp.title}</p>
                <p className="text-xs text-slate-500">
                  {exp.category} · <span className="font-mono">{formatDateIN(exp.date)}</span> ·{' '}
                  {exp.paymentMode}
                </p>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <span className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                  {formatINR(exp.amount)}
                </span>
                <button
                  type="button"
                  onClick={() => deleteExpense(exp.id)}
                  aria-label={`Delete ${exp.title}`}
                  className="flex h-8 w-8 items-center justify-center rounded-md border border-slate-200 text-slate-400 hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600 cursor-pointer"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Log Shop Expense"
        subtitle="Record an operating expense to reflect accurate net profit"
      >
        <form onSubmit={handleAddExpense} className="space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-slate-700">Expense Title *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Monthly Broadband & Electricity"
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-sm"
              >
                {EXPENSE_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">Amount (₹) *</label>
              <input
                type="number"
                min={1}
                required
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700">Payment Mode</label>
              <select
                value={paymentMode}
                onChange={(e) => setPaymentMode(e.target.value as 'Cash' | 'UPI' | 'Bank Transfer')}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm"
              >
                <option value="UPI">UPI</option>
                <option value="Cash">Cash</option>
                <option value="Bank Transfer">Bank Transfer</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">Paid To (Optional)</label>
              <input
                type="text"
                value={vendor}
                onChange={(e) => setVendor(e.target.value)}
                placeholder="Vendor or staff name"
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="min-h-[40px] rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[40px] rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
            >
              Save Expense
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
