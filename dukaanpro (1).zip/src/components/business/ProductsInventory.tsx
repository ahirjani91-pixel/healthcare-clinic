import React, {useMemo, useState} from 'react';
import {
  AlertTriangle,
  Edit3,
  Minus,
  Package,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import {useApp} from '../../context/AppContext';
import {Product} from '../../types/dukaan';
import {formatINR} from '../../utils/formatters';
import {EmptyState} from '../ui/EmptyState';
import {Modal} from '../ui/Modal';
import {StatCard} from '../ui/StatCard';

export const ProductsInventory: React.FC = () => {
  const {products, addProduct, updateProduct, deleteProduct, adjustProductStock} = useApp();

  const [query, setQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [onlyLowStock, setOnlyLowStock] = useState(false);

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);

  const [sku, setSku] = useState('');
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Atta & Grains');
  const [unit, setUnit] = useState('Pack');
  const [purchasePrice, setPurchasePrice] = useState(100);
  const [sellingPrice, setSellingPrice] = useState(125);
  const [gstRate, setGstRate] = useState(5);
  const [stock, setStock] = useState(20);
  const [minStock, setMinStock] = useState(5);

  const categories = useMemo(
    () => ['All', ...Array.from(new Set(products.map((p) => p.category)))],
    [products]
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      if (categoryFilter !== 'All' && p.category !== categoryFilter) return false;
      if (onlyLowStock && p.stock > p.minStock) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
      );
    });
  }, [products, query, categoryFilter, onlyLowStock]);

  const totalCostValue = products.reduce((s, p) => s + p.purchasePrice * p.stock, 0);
  const totalRetailValue = products.reduce((s, p) => s + p.sellingPrice * p.stock, 0);
  const lowStockCount = products.filter((p) => p.stock <= p.minStock).length;

  const openAdd = () => {
    setEditing(null);
    setSku(`SKU-${Math.floor(1000 + Math.random() * 8999)}`);
    setName('');
    setCategory(categories[1] ?? 'Groceries');
    setUnit('Pack');
    setPurchasePrice(100);
    setSellingPrice(120);
    setGstRate(5);
    setStock(25);
    setMinStock(8);
    setModalOpen(true);
  };

  const openEdit = (p: Product) => {
    setEditing(p);
    setSku(p.sku);
    setName(p.name);
    setCategory(p.category);
    setUnit(p.unit);
    setPurchasePrice(p.purchasePrice);
    setSellingPrice(p.sellingPrice);
    setGstRate(p.gstRate);
    setStock(p.stock);
    setMinStock(p.minStock);
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const payload = {
      sku: sku.trim() || `SKU-${Date.now()}`,
      name: name.trim(),
      category: category.trim() || 'General',
      unit: unit.trim() || 'Pcs',
      purchasePrice: Number(purchasePrice) || 0,
      sellingPrice: Number(sellingPrice) || 0,
      gstRate: Number(gstRate) || 0,
      stock: Math.max(0, Number(stock) || 0),
      minStock: Math.max(0, Number(minStock) || 0),
    };
    if (editing) {
      updateProduct(editing.id, payload);
    } else {
      addProduct(payload);
    }
    setModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          label="Inventory Cost Value"
          value={formatINR(totalCostValue)}
          subtext={`${products.length} active SKUs`}
          tone="blue"
          icon={Package}
        />
        <StatCard
          label="Projected Retail Value"
          value={formatINR(totalRetailValue)}
          subtext={`Est. margin ${formatINR(totalRetailValue - totalCostValue)}`}
          tone="positive"
          icon={Package}
        />
        <StatCard
          label="Low Stock Alerts"
          value={String(lowStockCount)}
          subtext={lowStockCount > 0 ? 'Reorder needed soon' : 'All stock healthy'}
          tone={lowStockCount > 0 ? 'warning' : 'positive'}
          icon={AlertTriangle}
        />
      </div>

      {/* Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-wrap items-center gap-2.5">
          <div className="relative flex-1 min-w-[200px] max-w-sm">
            <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search item name or SKU..."
              className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm focus:border-blue-600 focus:outline-none"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700"
          >
            {categories.map((c) => (
              <option key={c} value={c}>
                {c === 'All' ? 'All Categories' : c}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => setOnlyLowStock(!onlyLowStock)}
            className={`min-h-[38px] rounded-lg border px-3 text-xs font-semibold transition-colors cursor-pointer ${
              onlyLowStock
                ? 'border-amber-300 bg-amber-50 text-amber-800'
                : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
            }`}
          >
            Low Stock Only
          </button>
        </div>

        <button
          type="button"
          onClick={openAdd}
          className="inline-flex min-h-[40px] items-center justify-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer whitespace-nowrap"
        >
          <Plus className="h-4 w-4" />
          <span>Add Product</span>
        </button>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={Package}
          title="No products in this view"
          description="Add a product to your catalog or clear your active filters."
          actionLabel="Add Product"
          onAction={openAdd}
        />
      ) : (
        <>
          {/* Desktop Table */}
          <div className="hidden md:block overflow-hidden rounded-xl border border-slate-200 bg-white">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                    <th className="px-4 py-3">Item &amp; SKU</th>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3 text-right">Purchase (₹)</th>
                    <th className="px-4 py-3 text-right">Selling (₹)</th>
                    <th className="px-4 py-3 text-right">GST</th>
                    <th className="px-4 py-3 text-center">Stock</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.map((p) => {
                    const isLow = p.stock <= p.minStock;
                    return (
                      <tr key={p.id} className="hover:bg-slate-50/70">
                        <td className="px-4 py-3.5">
                          <p className="font-semibold text-slate-900">{p.name}</p>
                          <p className="font-mono text-[11px] text-slate-500">{p.sku}</p>
                        </td>
                        <td className="px-4 py-3.5 text-xs text-slate-600">{p.category}</td>
                        <td className="px-4 py-3.5 text-right font-mono text-xs text-slate-600 tabular-nums">
                          {formatINR(p.purchasePrice)}
                        </td>
                        <td className="px-4 py-3.5 text-right font-mono text-sm font-semibold text-slate-900 tabular-nums">
                          {formatINR(p.sellingPrice)}
                        </td>
                        <td className="px-4 py-3.5 text-right font-mono text-xs text-slate-600">
                          {p.gstRate}%
                        </td>
                        <td className="px-4 py-3.5">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => adjustProductStock(p.id, -1)}
                              aria-label={`Decrease stock for ${p.name}`}
                              className="flex h-7 w-7 items-center justify-center rounded border border-slate-200 text-slate-600 hover:bg-slate-100 cursor-pointer"
                            >
                              <Minus className="h-3 w-3" />
                            </button>
                            <span
                              className={`min-w-[68px] text-center font-mono text-xs font-semibold tabular-nums ${
                                isLow ? 'text-rose-600' : 'text-slate-900'
                              }`}
                            >
                              {p.stock} {p.unit}
                            </span>
                            <button
                              type="button"
                              onClick={() => adjustProductStock(p.id, 1)}
                              aria-label={`Increase stock for ${p.name}`}
                              className="flex h-7 w-7 items-center justify-center rounded border border-slate-200 text-slate-600 hover:bg-slate-100 cursor-pointer"
                            >
                              <Plus className="h-3 w-3" />
                            </button>
                          </div>
                        </td>
                        <td className="px-4 py-3.5 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => openEdit(p)}
                              aria-label={`Edit ${p.name}`}
                              className="flex h-8 w-8 items-center justify-center rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50 cursor-pointer"
                            >
                              <Edit3 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => deleteProduct(p.id)}
                              aria-label={`Delete ${p.name}`}
                              className="flex h-8 w-8 items-center justify-center rounded-md border border-rose-200 bg-rose-50 text-rose-600 hover:bg-rose-100 cursor-pointer"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile Cards */}
          <div className="space-y-3 md:hidden">
            {filtered.map((p) => {
              const isLow = p.stock <= p.minStock;
              return (
                <div key={p.id} className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="text-sm font-semibold text-slate-900">{p.name}</h3>
                      <p className="text-xs text-slate-500">
                        {p.category} · <span className="font-mono">{p.sku}</span> · GST {p.gstRate}%
                      </p>
                    </div>
                    <span className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                      {formatINR(p.sellingPrice)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between border-t border-slate-100 pt-3">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => adjustProductStock(p.id, -1)}
                        className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-700 cursor-pointer"
                      >
                        <Minus className="h-4 w-4" />
                      </button>
                      <span
                        className={`font-mono text-xs font-semibold tabular-nums ${
                          isLow ? 'text-rose-600' : 'text-slate-900'
                        }`}
                      >
                        {p.stock} {p.unit}
                      </span>
                      <button
                        type="button"
                        onClick={() => adjustProductStock(p.id, 1)}
                        className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-700 cursor-pointer"
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => openEdit(p)}
                        className="min-h-[36px] rounded-lg border border-slate-200 px-3 text-xs font-semibold text-slate-700 cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() => deleteProduct(p.id)}
                        className="min-h-[36px] rounded-lg border border-rose-200 bg-rose-50 px-3 text-xs font-semibold text-rose-700 cursor-pointer"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Product' : 'Add New Product'}
        subtitle="Set purchase rate, selling rate, GST slab, and minimum stock alert"
      >
        <form onSubmit={handleSave} className="space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-slate-700">Product Name *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Tata Salt Vacuum Evaporated 1kg"
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700">SKU Code</label>
              <input
                type="text"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-xs focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">Category</label>
              <input
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700">Purchase (₹)</label>
              <input
                type="number"
                min={0}
                required
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">Selling (₹)</label>
              <input
                type="number"
                min={0}
                required
                value={sellingPrice}
                onChange={(e) => setSellingPrice(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">GST %</label>
              <select
                value={gstRate}
                onChange={(e) => setGstRate(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-2 font-mono text-sm focus:border-blue-600 focus:outline-none"
              >
                {[0, 5, 12, 18, 28].map((r) => (
                  <option key={r} value={r}>
                    {r}%
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700">Unit</label>
              <input
                type="text"
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder="Pack / Kg / Tin"
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">Current Stock</label>
              <input
                type="number"
                min={0}
                value={stock}
                onChange={(e) => setStock(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">Low Alert At</label>
              <input
                type="number"
                min={0}
                value={minStock}
                onChange={(e) => setMinStock(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="min-h-[40px] rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[40px] rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
            >
              {editing ? 'Update Product' : 'Add Product'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
