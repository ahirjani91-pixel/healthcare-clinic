import React, {useMemo, useState} from 'react';
import {
  Download,
  FileText,
  Plus,
  Printer,
  ReceiptIndianRupee,
  Search,
  Trash2,
} from 'lucide-react';
import {useApp} from '../../context/AppContext';
import {PaymentMode, TradeLineItem, TradeTransaction, TradeType} from '../../types/dukaan';
import {exportToCSV, formatDateIN, formatINR} from '../../utils/formatters';
import {EmptyState} from '../ui/EmptyState';
import {Modal} from '../ui/Modal';

export const SalesPurchases: React.FC = () => {
  const {
    activeBusinessUser,
    transactions,
    products,
    customers,
    createTradeTransaction,
  } = useApp();

  const [tab, setTab] = useState<'all' | TradeType>('all');
  const [query, setQuery] = useState('');
  const [builderOpen, setBuilderOpen] = useState(false);
  const [builderType, setBuilderType] = useState<TradeType>('sale');
  const [receiptTrx, setReceiptTrx] = useState<TradeTransaction | null>(null);

  // Builder state
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [partyName, setPartyName] = useState('');
  const [partyPhone, setPartyPhone] = useState('');
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('UPI');
  const [paidAmountInput, setPaidAmountInput] = useState<string>('');
  const [notes, setNotes] = useState('');
  const [lineItems, setLineItems] = useState<{productId: string; qty: number; rate: number}[]>([]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return transactions.filter((t) => {
      if (tab !== 'all' && t.type !== tab) return false;
      if (!q) return true;
      return (
        t.voucherNo.toLowerCase().includes(q) ||
        t.partyName.toLowerCase().includes(q)
      );
    });
  }, [transactions, tab, query]);

  const openBuilder = (type: TradeType) => {
    setBuilderType(type);
    const firstProd = products[0];
    setSelectedCustomerId(type === 'sale' && customers[0] ? customers[0].id : '');
    setPartyName(type === 'sale' && customers[0] ? customers[0].name : '');
    setPartyPhone(type === 'sale' && customers[0] ? customers[0].phone : '');
    setPaymentMode(type === 'sale' ? 'UPI' : 'Bank Transfer');
    setPaidAmountInput('');
    setNotes('');
    setLineItems(
      firstProd
        ? [
            {
              productId: firstProd.id,
              qty: 1,
              rate: type === 'sale' ? firstProd.sellingPrice : firstProd.purchasePrice,
            },
          ]
        : []
    );
    setBuilderOpen(true);
  };

  const handleCustomerSelect = (cid: string) => {
    setSelectedCustomerId(cid);
    const cust = customers.find((c) => c.id === cid);
    if (cust) {
      setPartyName(cust.name);
      setPartyPhone(cust.phone);
    } else {
      setPartyName('Walk-in Customer');
      setPartyPhone('—');
    }
  };

  const addLineRow = () => {
    const p = products[0];
    if (!p) return;
    setLineItems((prev) => [
      ...prev,
      {
        productId: p.id,
        qty: 1,
        rate: builderType === 'sale' ? p.sellingPrice : p.purchasePrice,
      },
    ]);
  };

  const updateLineRow = (idx: number, patch: Partial<{productId: string; qty: number; rate: number}>) => {
    setLineItems((prev) =>
      prev.map((row, i) => {
        if (i !== idx) return row;
        const updated = {...row, ...patch};
        if (patch.productId) {
          const p = products.find((prod) => prod.id === patch.productId);
          if (p) {
            updated.rate = builderType === 'sale' ? p.sellingPrice : p.purchasePrice;
          }
        }
        return updated;
      })
    );
  };

  const computedItems: TradeLineItem[] = lineItems
    .map((row) => {
      const p = products.find((prod) => prod.id === row.productId);
      if (!p) return null;
      const qty = Math.max(1, row.qty || 1);
      const rate = Math.max(0, row.rate || 0);
      return {
        productId: p.id,
        productName: p.name,
        qty,
        unit: p.unit,
        rate,
        gstRate: p.gstRate,
        lineTotal: qty * rate,
      };
    })
    .filter((x): x is TradeLineItem => x !== null);

  const subtotal = computedItems.reduce((s, i) => s + i.lineTotal, 0);
  const gstAmount = Math.round(
    computedItems.reduce((s, i) => s + (i.lineTotal * i.gstRate) / 100, 0)
  );
  const grandTotal = subtotal + gstAmount;

  const handleSubmitVoucher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (computedItems.length === 0) return;
    const paid =
      paymentMode === 'Udhar (Credit)'
        ? Math.min(grandTotal, Math.max(0, Number(paidAmountInput) || 0))
        : grandTotal;
    const due = Math.max(0, grandTotal - paid);

    const created = await createTradeTransaction({
      type: builderType,
      partyName: partyName.trim() || (builderType === 'sale' ? 'Walk-in Cash Counter' : 'Wholesale Supplier'),
      partyPhone: partyPhone.trim() || '—',
      customerId: builderType === 'sale' && selectedCustomerId ? selectedCustomerId : undefined,
      items: computedItems,
      subtotal,
      gstAmount,
      totalAmount: grandTotal,
      paidAmount: paid,
      dueAmount: due,
      paymentMode,
      date: '2026-11-20',
      notes: notes.trim() || undefined,
    });
    setBuilderOpen(false);
    if (created) {
      setReceiptTrx(created);
    }
  };

  const handleExport = () => {
    exportToCSV(
      'dukaanpro-sales-purchases.csv',
      filtered.map((t) => ({
        Voucher: t.voucherNo,
        Type: t.type,
        Party: t.partyName,
        Date: t.date,
        PaymentMode: t.paymentMode,
        Subtotal: t.subtotal,
        GST: t.gstAmount,
        Total: t.totalAmount,
        Paid: t.paidAmount,
        Due: t.dueAmount,
      }))
    );
  };

  return (
    <div className="space-y-5">
      {/* Top Toolbar */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
            {(
              [
                {id: 'all', label: 'All Vouchers'},
                {id: 'sale', label: 'Sales'},
                {id: 'purchase', label: 'Purchases'},
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={`rounded-md px-3 py-1.5 text-xs font-semibold cursor-pointer ${
                  tab === t.id ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="relative min-w-[200px] flex-1 sm:flex-initial">
            <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search voucher or party..."
              className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm focus:border-blue-600 focus:outline-none"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleExport}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            <span>CSV</span>
          </button>
          <button
            type="button"
            onClick={() => openBuilder('purchase')}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50 px-3.5 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-100 cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Record Purchase</span>
          </button>
          <button
            type="button"
            onClick={() => openBuilder('sale')}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>New Sale Bill</span>
          </button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={ReceiptIndianRupee}
          title="No vouchers found"
          description="Create your first GST sale invoice or supplier purchase entry."
          actionLabel="Create Sale Bill"
          onAction={() => openBuilder('sale')}
        />
      ) : (
        <>
          <div className="hidden md:block overflow-hidden rounded-xl border border-slate-200 bg-white">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                    <th className="px-4 py-3">Voucher</th>
                    <th className="px-4 py-3">Type</th>
                    <th className="px-4 py-3">Party Name</th>
                    <th className="px-4 py-3">Date</th>
                    <th className="px-4 py-3">Payment Mode</th>
                    <th className="px-4 py-3 text-right">Due (₹)</th>
                    <th className="px-4 py-3 text-right">Total (₹)</th>
                    <th className="px-4 py-3 text-right">Receipt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.map((trx) => (
                    <tr key={trx.id} className="hover:bg-slate-50/70">
                      <td className="px-4 py-3.5 font-mono text-xs font-semibold text-slate-800 whitespace-nowrap">
                        {trx.voucherNo}
                      </td>
                      <td className="px-4 py-3.5 whitespace-nowrap">
                        <span
                          className={`rounded-md px-2 py-0.5 text-xs font-semibold ${
                            trx.type === 'sale'
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-blue-50 text-blue-700'
                          }`}
                        >
                          {trx.type === 'sale' ? 'Sale' : 'Purchase'}
                        </span>
                      </td>
                      <td className="px-4 py-3.5">
                        <p className="font-medium text-slate-900">{trx.partyName}</p>
                        <p className="text-xs text-slate-500">{trx.items.length} line item(s)</p>
                      </td>
                      <td className="px-4 py-3.5 font-mono text-xs text-slate-500 whitespace-nowrap">
                        {formatDateIN(trx.date)}
                      </td>
                      <td className="px-4 py-3.5 text-xs text-slate-600 whitespace-nowrap">
                        {trx.paymentMode}
                      </td>
                      <td
                        className={`px-4 py-3.5 text-right font-mono text-xs font-semibold tabular-nums whitespace-nowrap ${
                          trx.dueAmount > 0 ? 'text-rose-600' : 'text-slate-400'
                        }`}
                      >
                        {trx.dueAmount > 0 ? formatINR(trx.dueAmount) : '—'}
                      </td>
                      <td className="px-4 py-3.5 text-right font-mono text-sm font-bold text-slate-900 tabular-nums whitespace-nowrap">
                        {formatINR(trx.totalAmount)}
                      </td>
                      <td className="px-4 py-3.5 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => setReceiptTrx(trx)}
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-slate-200 px-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                        >
                          <FileText className="h-3.5 w-3.5" />
                          <span>Bill</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="space-y-3 md:hidden">
            {filtered.map((trx) => (
              <button
                key={trx.id}
                type="button"
                onClick={() => setReceiptTrx(trx)}
                className="w-full rounded-xl border border-slate-200 bg-white p-4 text-left space-y-2 cursor-pointer"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-900 truncate">{trx.partyName}</p>
                    <p className="text-xs text-slate-500">
                      <span className="font-mono">{trx.voucherNo}</span> · {formatDateIN(trx.date)}
                    </p>
                  </div>
                  <span className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                    {formatINR(trx.totalAmount)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100">
                  <span
                    className={`rounded-md px-2 py-0.5 font-semibold ${
                      trx.type === 'sale'
                        ? 'bg-emerald-50 text-emerald-700'
                        : 'bg-blue-50 text-blue-700'
                    }`}
                  >
                    {trx.type === 'sale' ? 'Sale' : 'Purchase'} · {trx.paymentMode}
                  </span>
                  {trx.dueAmount > 0 ? (
                    <span className="font-mono font-semibold text-rose-600">
                      Due {formatINR(trx.dueAmount)}
                    </span>
                  ) : (
                    <span className="text-emerald-700 font-medium">Settled</span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </>
      )}

      {/* New Sale / Purchase Builder Modal */}
      <Modal
        open={builderOpen}
        onClose={() => setBuilderOpen(false)}
        title={builderType === 'sale' ? 'Create New Sale Bill' : 'Record Stock Purchase'}
        subtitle="Automatically updates product inventory and customer Udhar balance"
        maxWidthClass="max-w-2xl"
      >
        <form onSubmit={handleSubmitVoucher} className="space-y-4">
          {builderType === 'sale' ? (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700">Customer</label>
                <select
                  value={selectedCustomerId}
                  onChange={(e) => handleCustomerSelect(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
                >
                  <option value="">Walk-in Cash Counter</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.phone})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700">Party Display Name</label>
                <input
                  type="text"
                  required
                  value={partyName}
                  onChange={(e) => setPartyName(e.target.value)}
                  placeholder="Walk-in Customer"
                  className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
                />
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700">Supplier Name *</label>
                <input
                  type="text"
                  required
                  value={partyName}
                  onChange={(e) => setPartyName(e.target.value)}
                  placeholder="e.g. Metro Cash & Carry Wholesale"
                  className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700">Supplier Phone</label>
                <input
                  type="tel"
                  value={partyPhone}
                  onChange={(e) => setPartyPhone(e.target.value)}
                  placeholder="+91 98000 00000"
                  className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* Line Items */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-700">Line Items</span>
              <button
                type="button"
                onClick={addLineRow}
                className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Add Row</span>
              </button>
            </div>

            {lineItems.map((row, idx) => (
              <div
                key={idx}
                className="grid grid-cols-12 items-center gap-2 rounded-lg border border-slate-200 bg-slate-50/70 p-2"
              >
                <div className="col-span-12 sm:col-span-6">
                  <select
                    value={row.productId}
                    onChange={(e) => updateLineRow(idx, {productId: e.target.value})}
                    className="w-full rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-900"
                  >
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} (Stock: {p.stock})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="col-span-4 sm:col-span-2">
                  <input
                    type="number"
                    min={1}
                    value={row.qty}
                    onChange={(e) => updateLineRow(idx, {qty: Number(e.target.value)})}
                    aria-label="Quantity"
                    className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 font-mono text-xs"
                  />
                </div>
                <div className="col-span-6 sm:col-span-3">
                  <input
                    type="number"
                    min={0}
                    value={row.rate}
                    onChange={(e) => updateLineRow(idx, {rate: Number(e.target.value)})}
                    aria-label="Rate in INR"
                    className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 font-mono text-xs"
                  />
                </div>
                <div className="col-span-2 sm:col-span-1 flex justify-end">
                  <button
                    type="button"
                    disabled={lineItems.length <= 1}
                    onClick={() => setLineItems((prev) => prev.filter((_, i) => i !== idx))}
                    className="flex h-8 w-8 items-center justify-center rounded text-slate-400 hover:text-rose-600 disabled:opacity-30 cursor-pointer"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700">Payment Mode</label>
              <select
                value={paymentMode}
                onChange={(e) => setPaymentMode(e.target.value as PaymentMode)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm"
              >
                <option value="UPI">UPI (PhonePe / GPay / Paytm)</option>
                <option value="Cash">Cash</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Udhar (Credit)">Udhar (Credit)</option>
              </select>
            </div>

            {paymentMode === 'Udhar (Credit)' ? (
              <div>
                <label className="block text-xs font-semibold text-slate-700">
                  Advance Paid Now (₹)
                </label>
                <input
                  type="number"
                  min={0}
                  max={grandTotal}
                  value={paidAmountInput}
                  onChange={(e) => setPaidAmountInput(e.target.value)}
                  placeholder="0"
                  className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm"
                />
              </div>
            ) : (
              <div>
                <label className="block text-xs font-semibold text-slate-700">Notes (Optional)</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Reference / delivery note"
                  className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
                />
              </div>
            )}
          </div>

          {/* Totals Box */}
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5 space-y-1.5 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>Taxable Subtotal</span>
              <span className="font-mono tabular-nums">{formatINR(subtotal)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>GST Total</span>
              <span className="font-mono tabular-nums">{formatINR(gstAmount)}</span>
            </div>
            <div className="flex justify-between border-t border-slate-200 pt-2 text-sm font-bold text-slate-900">
              <span>Grand Total</span>
              <span className="font-mono tabular-nums text-blue-700">{formatINR(grandTotal)}</span>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setBuilderOpen(false)}
              className="min-h-[40px] rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[40px] rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
            >
              {builderType === 'sale' ? 'Generate Sale Bill' : 'Save Purchase Entry'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Invoice / Voucher Receipt Modal */}
      <Modal
        open={!!receiptTrx}
        onClose={() => setReceiptTrx(null)}
        title={receiptTrx ? `Voucher ${receiptTrx.voucherNo}` : ''}
        subtitle={receiptTrx ? `${formatDateIN(receiptTrx.date)} · ${receiptTrx.paymentMode}` : ''}
      >
        {receiptTrx && (
          <div className="space-y-4">
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs space-y-1">
              <p className="font-bold text-slate-900 text-sm">{activeBusinessUser?.businessName}</p>
              <p className="text-slate-600">
                {activeBusinessUser?.city}, {activeBusinessUser?.state} · GSTIN:{' '}
                <span className="font-mono">{activeBusinessUser?.gstin}</span>
              </p>
              <p className="pt-2 text-slate-700">
                <strong>{receiptTrx.type === 'sale' ? 'Billed To:' : 'Supplier:'}</strong>{' '}
                {receiptTrx.partyName} ({receiptTrx.partyPhone})
              </p>
            </div>

            <div className="divide-y divide-slate-100 border-y border-slate-200">
              {receiptTrx.items.map((item, i) => (
                <div key={i} className="flex items-center justify-between py-2.5 text-xs">
                  <div>
                    <p className="font-semibold text-slate-900">{item.productName}</p>
                    <p className="text-slate-500 font-mono">
                      {item.qty} {item.unit} × {formatINR(item.rate)} (GST {item.gstRate}%)
                    </p>
                  </div>
                  <span className="font-mono font-semibold text-slate-900 tabular-nums">
                    {formatINR(item.lineTotal)}
                  </span>
                </div>
              ))}
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-mono tabular-nums">{formatINR(receiptTrx.subtotal)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>GST</span>
                <span className="font-mono tabular-nums">{formatINR(receiptTrx.gstAmount)}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-slate-900 pt-1">
                <span>Total Amount</span>
                <span className="font-mono tabular-nums">{formatINR(receiptTrx.totalAmount)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Paid</span>
                <span className="font-mono tabular-nums">{formatINR(receiptTrx.paidAmount)}</span>
              </div>
              {receiptTrx.dueAmount > 0 && (
                <div className="flex justify-between font-semibold text-rose-600">
                  <span>Balance Due (Udhar)</span>
                  <span className="font-mono tabular-nums">{formatINR(receiptTrx.dueAmount)}</span>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-200 px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                <Printer className="h-3.5 w-3.5" />
                <span>Print</span>
              </button>
              <button
                type="button"
                onClick={() => setReceiptTrx(null)}
                className="min-h-[40px] rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
