import React, {useEffect, useMemo, useState} from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  BookOpenCheck,
  Check,
  Copy,
  Download,
  Plus,
} from 'lucide-react';
import {useApp} from '../../context/AppContext';
import {LedgerEntryType} from '../../types/dukaan';
import {exportToCSV, formatDateIN, formatINR} from '../../utils/formatters';
import {EmptyState} from '../ui/EmptyState';
import {Modal} from '../ui/Modal';
import {StatCard} from '../ui/StatCard';

interface UdharJamaLedgerProps {
  initialCustomerId?: string | null;
}

export const UdharJamaLedger: React.FC<UdharJamaLedgerProps> = ({initialCustomerId}) => {
  const {activeBusinessUser, customers, ledgerEntries, addLedgerEntry} = useApp();

  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(
    initialCustomerId ?? customers[0]?.id ?? ''
  );
  const [modalOpen, setModalOpen] = useState(false);
  const [entryType, setEntryType] = useState<LedgerEntryType>('jama');
  const [amount, setAmount] = useState<number>(500);
  const [mode, setMode] = useState<'Cash' | 'UPI' | 'Bank Transfer' | 'Credit Bill'>('UPI');
  const [note, setNote] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    if (initialCustomerId) {
      setSelectedCustomerId(initialCustomerId);
    } else if (!selectedCustomerId && customers[0]) {
      setSelectedCustomerId(customers[0].id);
    }
  }, [initialCustomerId, customers, selectedCustomerId]);

  const customerSummaries = useMemo(() => {
    return customers.map((c) => {
      const entries = ledgerEntries.filter((l) => l.customerId === c.id);
      const totalUdhar = entries
        .filter((l) => l.type === 'udhar')
        .reduce((s, l) => s + l.amount, 0);
      const totalJama = entries
        .filter((l) => l.type === 'jama')
        .reduce((s, l) => s + l.amount, 0);
      const netBalance = c.openingBalance + totalUdhar - totalJama;
      return {
        customer: c,
        entries,
        totalUdhar: c.openingBalance + totalUdhar,
        totalJama,
        netBalance,
      };
    });
  }, [customers, ledgerEntries]);

  const totalReceivable = customerSummaries.reduce(
    (s, item) => s + Math.max(0, item.netBalance),
    0
  );
  const totalJamaCollected = ledgerEntries
    .filter((l) => l.type === 'jama')
    .reduce((s, l) => s + l.amount, 0);
  const activeCreditCount = customerSummaries.filter((c) => c.netBalance > 0).length;

  const selectedSummary =
    customerSummaries.find((c) => c.customer.id === selectedCustomerId) ?? customerSummaries[0];

  const openEntryModal = (type: LedgerEntryType) => {
    setEntryType(type);
    setMode(type === 'udhar' ? 'Credit Bill' : 'UPI');
    setAmount(1000);
    setNote('');
    setModalOpen(true);
  };

  const handleSaveEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSummary || amount <= 0) return;
    addLedgerEntry({
      customerId: selectedSummary.customer.id,
      customerName: selectedSummary.customer.name,
      type: entryType,
      amount: Number(amount),
      mode,
      date: '2026-11-20',
      note:
        note.trim() ||
        (entryType === 'udhar' ? 'Credit goods given' : 'Payment received in Khata'),
    });
    setModalOpen(false);
  };

  const handleCopyReminder = async () => {
    if (!selectedSummary) return;
    const msg = `Namaste ${selectedSummary.customer.name}, friendly reminder from ${
      activeBusinessUser?.businessName ?? 'DukaanPro'
    }: your pending Udhar balance is ${formatINR(
      Math.max(0, selectedSummary.netBalance)
    )}. Kindly settle via UPI or cash at your convenience. Thank you!`;
    try {
      await navigator.clipboard.writeText(msg);
      setCopiedId(selectedSummary.customer.id);
      setTimeout(() => setCopiedId(null), 2200);
    } catch {
      // Fallback ignored if clipboard blocked
    }
  };

  const handleExportKhata = () => {
    if (!selectedSummary) return;
    exportToCSV(
      `khata-${selectedSummary.customer.name.replace(/\s+/g, '-').toLowerCase()}.csv`,
      selectedSummary.entries.map((e) => ({
        Date: e.date,
        Type: e.type === 'udhar' ? 'Udhar (Given)' : 'Jama (Received)',
        Mode: e.mode,
        AmountINR: e.amount,
        Note: e.note,
      }))
    );
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          label="Total You Will Get (Udhar)"
          value={formatINR(totalReceivable)}
          subtext={`Across ${activeCreditCount} customers with dues`}
          tone="danger"
          icon={ArrowUpRight}
        />
        <StatCard
          label="Total Jama Collected"
          value={formatINR(totalJamaCollected)}
          subtext="Payments settled into business"
          tone="positive"
          icon={ArrowDownLeft}
        />
        <StatCard
          label="Total Khata Parties"
          value={String(customers.length)}
          subtext="Click any customer to view passbook"
          tone="blue"
          icon={BookOpenCheck}
        />
      </div>

      {customers.length === 0 ? (
        <EmptyState
          icon={BookOpenCheck}
          title="No customers in Khata yet"
          description="Add a customer in the Customers directory to start tracking Udhar and Jama."
        />
      ) : (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Customer Party List */}
          <div className="rounded-xl border border-slate-200 bg-white overflow-hidden lg:col-span-4">
            <div className="border-b border-slate-100 px-4 py-3">
              <h2 className="text-sm font-bold text-slate-900">Customer Balances</h2>
            </div>
            <div className="divide-y divide-slate-100 max-h-[520px] overflow-y-auto">
              {customerSummaries.map(({customer, netBalance}) => {
                const isSelected = selectedSummary?.customer.id === customer.id;
                return (
                  <button
                    key={customer.id}
                    type="button"
                    onClick={() => setSelectedCustomerId(customer.id)}
                    className={`flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left transition-colors cursor-pointer ${
                      isSelected ? 'bg-blue-50/80' : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="min-w-0">
                      <p
                        className={`text-sm font-semibold truncate ${
                          isSelected ? 'text-blue-800' : 'text-slate-900'
                        }`}
                      >
                        {customer.name}
                      </p>
                      <p className="font-mono text-[11px] text-slate-500">{customer.phone}</p>
                    </div>
                    <div className="shrink-0 text-right">
                      <p
                        className={`font-mono text-sm font-bold tabular-nums ${
                          netBalance > 0
                            ? 'text-rose-600'
                            : netBalance < 0
                            ? 'text-emerald-700'
                            : 'text-slate-500'
                        }`}
                      >
                        {formatINR(Math.abs(netBalance))}
                      </p>
                      <p className="text-[10px] font-medium text-slate-500">
                        {netBalance > 0 ? 'Udhar Due' : netBalance < 0 ? 'Advance' : 'Settled'}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Customer Passbook */}
          {selectedSummary && (
            <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-8 space-y-5">
              <div className="flex flex-col gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="text-base font-bold text-slate-900">
                    {selectedSummary.customer.name}
                  </h2>
                  <p className="text-xs text-slate-500">
                    <span className="font-mono">{selectedSummary.customer.phone}</span> · Opening
                    Bal: <span className="font-mono">{formatINR(selectedSummary.customer.openingBalance)}</span>
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-left sm:text-right">
                    <span className="block text-[11px] font-medium text-slate-500">
                      Net Balance
                    </span>
                    <span
                      className={`font-mono text-xl font-bold tabular-nums ${
                        selectedSummary.netBalance > 0 ? 'text-rose-600' : 'text-emerald-700'
                      }`}
                    >
                      {formatINR(Math.abs(selectedSummary.netBalance))}{' '}
                      <span className="text-xs font-semibold">
                        {selectedSummary.netBalance > 0 ? 'Udhar' : 'Settled'}
                      </span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => openEntryModal('udhar')}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-100 cursor-pointer"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Give Udhar (Credit)</span>
                </button>
                <button
                  type="button"
                  onClick={() => openEntryModal('jama')}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-700 cursor-pointer"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Receive Jama (Payment)</span>
                </button>

                {selectedSummary.netBalance > 0 && (
                  <button
                    type="button"
                    onClick={handleCopyReminder}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-100 cursor-pointer"
                  >
                    {copiedId === selectedSummary.customer.id ? (
                      <>
                        <Check className="h-3.5 w-3.5" />
                        <span>Reminder Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        <span>Copy WhatsApp Reminder</span>
                      </>
                    )}
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleExportKhata}
                  className="ml-auto inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Export CSV</span>
                </button>
              </div>

              {/* Ledger Entries */}
              <div className="divide-y divide-slate-100">
                {selectedSummary.entries.length === 0 ? (
                  <p className="py-8 text-center text-xs text-slate-500">
                    No Udhar or Jama entries logged yet for this customer.
                  </p>
                ) : (
                  selectedSummary.entries.map((entry) => (
                    <div
                      key={entry.id}
                      className="flex items-center justify-between gap-3 py-3"
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-900">{entry.note}</p>
                        <p className="text-xs text-slate-500">
                          <span className="font-mono">{formatDateIN(entry.date)}</span> · {entry.mode}
                        </p>
                      </div>
                      <div className="shrink-0 text-right">
                        <span
                          className={`font-mono text-sm font-bold tabular-nums ${
                            entry.type === 'udhar' ? 'text-rose-600' : 'text-emerald-700'
                          }`}
                        >
                          {entry.type === 'udhar' ? '+' : '-'}{' '}
                          {formatINR(entry.amount)}
                        </span>
                        <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                          {entry.type === 'udhar' ? 'Udhar Given' : 'Jama Received'}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      )}

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={
          entryType === 'udhar' ? 'Record Udhar (Credit Given)' : 'Record Jama (Payment Received)'
        }
        subtitle={selectedSummary ? `Customer: ${selectedSummary.customer.name}` : ''}
      >
        <form onSubmit={handleSaveEntry} className="space-y-3.5">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700">Amount (₹) *</label>
              <input
                type="number"
                min={1}
                required
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700">Payment Mode</label>
              <select
                value={mode}
                onChange={(e) =>
                  setMode(e.target.value as 'Cash' | 'UPI' | 'Bank Transfer' | 'Credit Bill')
                }
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm"
              >
                <option value="UPI">UPI</option>
                <option value="Cash">Cash</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Credit Bill">Credit Bill</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700">Note / Reference</label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder={
                entryType === 'udhar'
                  ? 'e.g. Monthly groceries on credit'
                  : 'e.g. Received via PhonePe'
              }
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="min-h-[40px] rounded-lg border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`min-h-[40px] rounded-lg px-4 py-2 text-xs font-semibold text-white cursor-pointer ${
                entryType === 'udhar'
                  ? 'bg-rose-600 hover:bg-rose-700'
                  : 'bg-emerald-600 hover:bg-emerald-700'
              }`}
            >
              Save {entryType === 'udhar' ? 'Udhar' : 'Jama'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
