import React from 'react';
import {WifiOff} from 'lucide-react';
import {useOnlineStatus} from '../../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed bottom-20 left-4 right-4 z-50 mx-auto flex max-w-md items-center gap-2.5 rounded-lg border border-amber-200 bg-amber-50 px-3.5 py-2.5 text-xs font-medium text-amber-900 shadow-md lg:bottom-4 lg:left-auto lg:right-4"
    >
      <WifiOff className="h-4 w-4 shrink-0 text-amber-700" />
      <span>Offline mode active — working with locally saved data.</span>
    </div>
  );
};
