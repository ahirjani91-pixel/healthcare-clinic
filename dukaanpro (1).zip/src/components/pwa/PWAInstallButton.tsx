import React, {useState} from 'react';
import {Download, Share, Smartphone, X} from 'lucide-react';
import {usePWAInstall} from '../../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  compact?: boolean;
  showGuideFallback?: boolean;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  compact = false,
  showGuideFallback = false,
}) => {
  const {isInstallable, isInstalled, isIOS, install} = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className="inline-flex min-h-[40px] items-center justify-center gap-2 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Download className="h-4 w-4 shrink-0" />
        <span>{compact ? 'Install' : 'Install App'}</span>
      </button>
    );
  }

  if (isIOS || showGuideFallback) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowGuideModal(true)}
          className="inline-flex min-h-[40px] items-center justify-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-3.5 py-2 text-xs font-semibold text-blue-700 transition-colors hover:bg-blue-100 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Smartphone className="h-4 w-4 shrink-0" />
          <span>{compact ? 'Install' : isIOS ? 'Install on iOS' : 'Install PWA'}</span>
        </button>

        {showGuideModal && (
          <div
            className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 p-0 sm:items-center sm:p-4 backdrop-blur-xs"
            role="dialog"
            aria-modal="true"
            aria-labelledby="pwa-install-title"
          >
            <div className="w-full max-w-md rounded-t-2xl sm:rounded-2xl border border-slate-200 bg-white p-6 shadow-xl">
              <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-slate-200 sm:hidden" />
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 id="pwa-install-title" className="text-base font-semibold text-slate-900">
                    Install DukaanPro App
                  </h3>
                  <p className="mt-1 text-sm text-slate-500">
                    Add DukaanPro to your home screen for fast offline-ready access.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowGuideModal(false)}
                  aria-label="Close install instructions"
                  className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-600 cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {isIOS ? (
                <ol className="mt-4 space-y-3 text-sm text-slate-700">
                  <li className="flex items-start gap-2.5">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-blue-50 font-mono text-xs font-semibold text-blue-700">
                      1
                    </span>
                    <span>
                      Tap the <strong className="inline-flex items-center gap-1 font-semibold text-slate-900"><Share className="h-3.5 w-3.5" /> Share</strong> button in the Safari toolbar.
                    </span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-blue-50 font-mono text-xs font-semibold text-blue-700">
                      2
                    </span>
                    <span>
                      Scroll down and select <strong className="font-semibold text-slate-900">Add to Home Screen</strong>.
                    </span>
                  </li>
                </ol>
              ) : (
                <ol className="mt-4 space-y-3 text-sm text-slate-700">
                  <li className="flex items-start gap-2.5">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-blue-50 font-mono text-xs font-semibold text-blue-700">
                      1
                    </span>
                    <span>
                      Open your browser menu or address bar install icon in Chrome, Edge, or Android.
                    </span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-blue-50 font-mono text-xs font-semibold text-blue-700">
                      2
                    </span>
                    <span>
                      Click <strong className="font-semibold text-slate-900">Install DukaanPro</strong> to launch as a standalone app.
                    </span>
                  </li>
                </ol>
              )}

              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                className="mt-6 w-full rounded-lg bg-blue-600 py-2.5 text-sm font-semibold text-white hover:bg-blue-700 transition-colors cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
