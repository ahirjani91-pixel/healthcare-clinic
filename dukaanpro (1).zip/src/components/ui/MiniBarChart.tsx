import React, {useState} from 'react';
import {formatINR} from '../../utils/formatters';

export interface ChartBarPoint {
  label: string;
  primary: number;
  secondary?: number;
}

interface MiniBarChartProps {
  data: ChartBarPoint[];
  primaryLabel: string;
  secondaryLabel?: string;
  primaryColorClass?: string;
  secondaryColorClass?: string;
}

export const MiniBarChart: React.FC<MiniBarChartProps> = ({
  data,
  primaryLabel,
  secondaryLabel,
  primaryColorClass = 'bg-blue-600',
  secondaryColorClass = 'bg-slate-300',
}) => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const maxVal = Math.max(
    1,
    ...data.map((d) => Math.max(d.primary, d.secondary ?? 0))
  );

  const activePoint = activeIndex !== null ? data[activeIndex] : null;

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-4">
          <span className="inline-flex items-center gap-1.5 font-medium text-slate-700">
            <span className={`h-2.5 w-2.5 rounded-xs ${primaryColorClass}`} />
            {primaryLabel}
          </span>
          {secondaryLabel && (
            <span className="inline-flex items-center gap-1.5 font-medium text-slate-600">
              <span className={`h-2.5 w-2.5 rounded-xs ${secondaryColorClass}`} />
              {secondaryLabel}
            </span>
          )}
        </div>
        {activePoint ? (
          <div className="font-mono text-xs text-slate-700 tabular-nums">
            <span className="font-semibold">{activePoint.label}:</span>{' '}
            <span>{formatINR(activePoint.primary)}</span>
            {secondaryLabel && activePoint.secondary !== undefined && (
              <span className="text-slate-500"> / {formatINR(activePoint.secondary)}</span>
            )}
          </div>
        ) : (
          <span className="text-slate-400">Tap or hover bars to inspect</span>
        )}
      </div>

      <div className="grid grid-cols-6 sm:grid-cols-7 gap-2 sm:gap-3 items-end h-44 pt-4 border-b border-slate-100">
        {data.map((item, idx) => {
          const pHeight = Math.max(6, Math.round((item.primary / maxVal) * 100));
          const sHeight =
            item.secondary !== undefined
              ? Math.max(6, Math.round((item.secondary / maxVal) * 100))
              : 0;
          const isSelected = activeIndex === idx;
          return (
            <button
              key={item.label}
              type="button"
              onMouseEnter={() => setActiveIndex(idx)}
              onMouseLeave={() => setActiveIndex(null)}
              onFocus={() => setActiveIndex(idx)}
              onClick={() => setActiveIndex(isSelected ? null : idx)}
              className="group flex h-full flex-col items-center justify-end gap-1.5 focus:outline-none cursor-pointer"
            >
              <div className="flex w-full flex-1 items-end justify-center gap-1 px-0.5">
                <div
                  style={{height: `${pHeight}%`}}
                  className={`w-full max-w-[18px] rounded-t-sm transition-opacity ${primaryColorClass} ${
                    activeIndex !== null && !isSelected ? 'opacity-50' : 'opacity-100'
                  }`}
                />
                {secondaryLabel && item.secondary !== undefined && (
                  <div
                    style={{height: `${sHeight}%`}}
                    className={`w-full max-w-[18px] rounded-t-sm transition-opacity ${secondaryColorClass} ${
                      activeIndex !== null && !isSelected ? 'opacity-50' : 'opacity-100'
                    }`}
                  />
                )}
              </div>
              <span
                className={`text-[11px] font-medium pb-1.5 ${
                  isSelected ? 'text-blue-700 font-semibold' : 'text-slate-500'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
