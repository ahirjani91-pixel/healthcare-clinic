import React from 'react';
import {LucideIcon} from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string;
  subtext?: string;
  tone?: 'neutral' | 'positive' | 'warning' | 'danger' | 'blue';
  icon?: LucideIcon;
}

const TONE_MAP: Record<NonNullable<StatCardProps['tone']>, string> = {
  neutral: 'text-slate-600 bg-slate-100',
  blue: 'text-blue-700 bg-blue-50',
  positive: 'text-emerald-700 bg-emerald-50',
  warning: 'text-amber-700 bg-amber-50',
  danger: 'text-rose-700 bg-rose-50',
};

const SUBTEXT_COLOR: Record<NonNullable<StatCardProps['tone']>, string> = {
  neutral: 'text-slate-500',
  blue: 'text-blue-700',
  positive: 'text-emerald-700',
  warning: 'text-amber-700',
  danger: 'text-rose-700',
};

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  subtext,
  tone = 'neutral',
  icon: Icon,
}) => {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 sm:p-5">
      <div className="flex items-center justify-between gap-3">
        <span className="text-xs font-medium text-slate-500 truncate">{label}</span>
        {Icon && (
          <span
            className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${TONE_MAP[tone]}`}
          >
            <Icon className="h-4 w-4" />
          </span>
        )}
      </div>
      <div className="mt-2.5 font-mono text-2xl font-bold tracking-tight text-slate-900 tabular-nums">
        {value}
      </div>
      {subtext && (
        <p className={`mt-1.5 text-xs font-medium ${SUBTEXT_COLOR[tone]} truncate`}>{subtext}</p>
      )}
    </div>
  );
};
