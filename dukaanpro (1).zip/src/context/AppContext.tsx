import React, {createContext, useCallback, useContext, useState} from 'react';
import {
  AuthSession,
  Customer,
  ExpenseRecord,
  LedgerEntry,
  PlatformUser,
  Product,
  TradeTransaction,
  UserStatus,
} from '../types/dukaan';

interface RegisterBusinessInput {
  name: string;
  email: string;
  password: string;
  phone: string;
  businessName: string;
  businessCategory: string;
  city: string;
  state: string;
  gstin: string;
}

interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  deactivatedUsers: number;
  blockedUsers: number;
  totalBusinesses: number;
}

interface AdminAuthStatus {
  isPasscodeConfigured: boolean;
  ownerEmail: string;
}

interface AppContextValue {
  session: AuthSession | null;
  activeBusinessUser: PlatformUser | null;
  users: PlatformUser[];
  adminStats: AdminStats;
  products: Product[];
  transactions: TradeTransaction[];
  customers: Customer[];
  ledgerEntries: LedgerEntry[];
  expenses: ExpenseRecord[];
  isSyncing: boolean;

  // Auth actions
  getAdminAuthStatus: () => Promise<AdminAuthStatus>;
  setupAdminPasscode: (email: string, passcode: string) => Promise<{ok: boolean; error?: string}>;
  loginAsSuperAdmin: (email: string, passcode: string) => Promise<{ok: boolean; error?: string}>;
  loginAsBusinessUser: (email: string, password: string) => Promise<{ok: boolean; error?: string}>;
  loginAsDemoBusiness: (email: string) => Promise<{ok: boolean; error?: string}>;
  registerBusinessAccount: (input: RegisterBusinessInput) => Promise<{ok: boolean; error?: string}>;
  logout: () => void;

  // Super Admin RBAC actions
  refreshAdminUsers: () => Promise<void>;
  setUserStatus: (userId: string, status: UserStatus) => Promise<void>;
  setUserBlocked: (userId: string, isBlocked: boolean) => Promise<void>;
  deleteUser: (userId: string) => Promise<void>;
  updateUserAndBusiness: (userId: string, updates: Partial<PlatformUser>) => Promise<{ok: boolean; error?: string}>;

  // Scoped Business User actions
  addProduct: (input: Omit<Product, 'id' | 'businessId' | 'updatedAt'>) => Promise<void>;
  updateProduct: (productId: string, updates: Partial<Product>) => Promise<void>;
  deleteProduct: (productId: string) => Promise<void>;
  adjustProductStock: (productId: string, delta: number) => Promise<void>;
  createTradeTransaction: (
    input: Omit<TradeTransaction, 'id' | 'businessId' | 'voucherNo'>
  ) => Promise<TradeTransaction | null>;
  addCustomer: (input: Omit<Customer, 'id' | 'businessId' | 'createdAt'>) => Promise<void>;
  updateCustomer: (customerId: string, updates: Partial<Customer>) => Promise<void>;
  addLedgerEntry: (input: Omit<LedgerEntry, 'id' | 'businessId'>) => Promise<void>;
  addExpense: (input: Omit<ExpenseRecord, 'id' | 'businessId'>) => Promise<void>;
  deleteExpense: (expenseId: string) => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

const EMPTY_STATS: AdminStats = {
  totalUsers: 0,
  activeUsers: 0,
  deactivatedUsers: 0,
  blockedUsers: 0,
  totalBusinesses: 0,
};

export const AppProvider: React.FC<{children: React.ReactNode}> = ({children}) => {
  // Bearer token held strictly in React memory (never persisted in localStorage/sessionStorage)
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [session, setSession] = useState<AuthSession | null>(null);
  const [activeBusinessUser, setActiveBusinessUser] = useState<PlatformUser | null>(null);

  const [users, setUsers] = useState<PlatformUser[]>([]);
  const [adminStats, setAdminStats] = useState<AdminStats>(EMPTY_STATS);

  const [products, setProducts] = useState<Product[]>([]);
  const [transactions, setTransactions] = useState<TradeTransaction[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [ledgerEntries, setLedgerEntries] = useState<LedgerEntry[]>([]);
  const [expenses, setExpenses] = useState<ExpenseRecord[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);

  const logout = useCallback(() => {
    setAuthToken(null);
    setSession(null);
    setActiveBusinessUser(null);
    setUsers([]);
    setAdminStats(EMPTY_STATS);
    setProducts([]);
    setTransactions([]);
    setCustomers([]);
    setLedgerEntries([]);
    setExpenses([]);
  }, []);

  const apiFetch = useCallback(
    async <T,>(
      url: string,
      options: RequestInit = {},
      tokenOverride?: string | null
    ): Promise<{ok: boolean; status: number; data?: T; error?: string}> => {
      const token = tokenOverride !== undefined ? tokenOverride : authToken;
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...(options.headers as Record<string, string> | undefined),
      };
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }
      try {
        const res = await fetch(url, {...options, headers});
        const body = await res.json().catch(() => ({}));
        if (!res.ok) {
          if (res.status === 401 || (res.status === 403 && url.startsWith('/api/business'))) {
            if (tokenOverride === undefined) {
              logout();
            }
          }
          return {
            ok: false,
            status: res.status,
            error: typeof body?.error === 'string' ? body.error : 'Request failed',
          };
        }
        return {ok: true, status: res.status, data: body as T};
      } catch {
        return {ok: false, status: 0, error: 'Network error communicating with server.'};
      }
    },
    [authToken, logout]
  );

  const loadAdminUsersWithToken = useCallback(
    async (token: string) => {
      setIsSyncing(true);
      const res = await apiFetch<{stats: AdminStats; users: PlatformUser[]}>(
        '/api/admin/users',
        {method: 'GET'},
        token
      );
      setIsSyncing(false);
      if (res.ok && res.data) {
        setUsers(res.data.users);
        setAdminStats(res.data.stats);
      }
    },
    [apiFetch]
  );

  const loadBusinessWorkspaceWithToken = useCallback(
    async (token: string) => {
      setIsSyncing(true);
      const res = await apiFetch<{
        user: PlatformUser;
        products: Product[];
        transactions: TradeTransaction[];
        customers: Customer[];
        ledgerEntries: LedgerEntry[];
        expenses: ExpenseRecord[];
      }>('/api/business/workspace', {method: 'GET'}, token);
      setIsSyncing(false);
      if (res.ok && res.data) {
        setActiveBusinessUser(res.data.user);
        setProducts(res.data.products);
        setTransactions(res.data.transactions);
        setCustomers(res.data.customers);
        setLedgerEntries(res.data.ledgerEntries);
        setExpenses(res.data.expenses);
      }
    },
    [apiFetch]
  );

  const getAdminAuthStatus = async (): Promise<AdminAuthStatus> => {
    const res = await apiFetch<AdminAuthStatus>('/api/auth/admin/status', {method: 'GET'}, null);
    if (res.ok && res.data) return res.data;
    return {isPasscodeConfigured: true, ownerEmail: 'ahirjani91@gmail.com'};
  };

  const setupAdminPasscode = async (email: string, passcode: string) => {
    const res = await apiFetch<{token: string; session: AuthSession}>(
      '/api/auth/admin/setup',
      {
        method: 'POST',
        body: JSON.stringify({email, passcode}),
      },
      null
    );
    if (!res.ok || !res.data) {
      return {ok: false, error: res.error ?? 'Unable to complete owner setup.'};
    }
    setAuthToken(res.data.token);
    setSession(res.data.session);
    await loadAdminUsersWithToken(res.data.token);
    return {ok: true};
  };

  const loginAsSuperAdmin = async (email: string, passcode: string) => {
    const res = await apiFetch<{token: string; session: AuthSession}>(
      '/api/auth/admin/login',
      {
        method: 'POST',
        body: JSON.stringify({email, passcode}),
      },
      null
    );
    if (!res.ok || !res.data) {
      return {ok: false, error: res.error ?? 'Invalid administrator credentials.'};
    }
    setAuthToken(res.data.token);
    setSession(res.data.session);
    await loadAdminUsersWithToken(res.data.token);
    return {ok: true};
  };

  const loginAsBusinessUser = async (email: string, password: string) => {
    const res = await apiFetch<{token: string; session: AuthSession}>(
      '/api/auth/business/login',
      {
        method: 'POST',
        body: JSON.stringify({email, password}),
      },
      null
    );
    if (!res.ok || !res.data) {
      return {ok: false, error: res.error ?? 'Unable to sign in.'};
    }
    setAuthToken(res.data.token);
    setSession(res.data.session);
    await loadBusinessWorkspaceWithToken(res.data.token);
    return {ok: true};
  };

  const loginAsDemoBusiness = async (email: string) => {
    const res = await apiFetch<{token: string; session: AuthSession}>(
      '/api/auth/business/demo',
      {
        method: 'POST',
        body: JSON.stringify({email}),
      },
      null
    );
    if (!res.ok || !res.data) {
      return {ok: false, error: res.error ?? 'Unable to sign in.'};
    }
    setAuthToken(res.data.token);
    setSession(res.data.session);
    await loadBusinessWorkspaceWithToken(res.data.token);
    return {ok: true};
  };

  const registerBusinessAccount = async (input: RegisterBusinessInput) => {
    const res = await apiFetch<{token: string; session: AuthSession}>(
      '/api/auth/business/register',
      {
        method: 'POST',
        body: JSON.stringify(input),
      },
      null
    );
    if (!res.ok || !res.data) {
      return {ok: false, error: res.error ?? 'Registration failed.'};
    }
    setAuthToken(res.data.token);
    setSession(res.data.session);
    await loadBusinessWorkspaceWithToken(res.data.token);
    return {ok: true};
  };

  // --- Super Admin RBAC Actions ---
  const refreshAdminUsers = async () => {
    if (authToken && session?.role === 'super_admin') {
      await loadAdminUsersWithToken(authToken);
    }
  };

  const setUserStatus = async (userId: string, status: UserStatus) => {
    const res = await apiFetch<{user: PlatformUser}>(`/api/admin/users/${userId}/status`, {
      method: 'POST',
      body: JSON.stringify({status}),
    });
    if (res.ok && res.data) {
      await refreshAdminUsers();
    }
  };

  const setUserBlocked = async (userId: string, isBlocked: boolean) => {
    const res = await apiFetch<{user: PlatformUser}>(`/api/admin/users/${userId}/block`, {
      method: 'POST',
      body: JSON.stringify({isBlocked}),
    });
    if (res.ok && res.data) {
      await refreshAdminUsers();
    }
  };

  const deleteUser = async (userId: string) => {
    const res = await apiFetch(`/api/admin/users/${userId}`, {method: 'DELETE'});
    if (res.ok) {
      await refreshAdminUsers();
    }
  };

  const updateUserAndBusiness = async (userId: string, updates: Partial<PlatformUser>) => {
    const res = await apiFetch<{user: PlatformUser}>(`/api/admin/users/${userId}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
    if (!res.ok) {
      return {ok: false, error: res.error ?? 'Failed to update user.'};
    }
    await refreshAdminUsers();
    return {ok: true};
  };

  // --- Scoped Business Actions ---
  const addProduct = async (input: Omit<Product, 'id' | 'businessId' | 'updatedAt'>) => {
    const res = await apiFetch<{product: Product}>('/api/business/products', {
      method: 'POST',
      body: JSON.stringify(input),
    });
    if (res.ok && res.data) {
      setProducts((prev) => [res.data!.product, ...prev]);
    }
  };

  const updateProduct = async (productId: string, updates: Partial<Product>) => {
    const res = await apiFetch<{product: Product}>(`/api/business/products/${productId}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
    if (res.ok && res.data) {
      setProducts((prev) => prev.map((p) => (p.id === productId ? res.data!.product : p)));
    }
  };

  const deleteProduct = async (productId: string) => {
    const res = await apiFetch(`/api/business/products/${productId}`, {method: 'DELETE'});
    if (res.ok) {
      setProducts((prev) => prev.filter((p) => p.id !== productId));
    }
  };

  const adjustProductStock = async (productId: string, delta: number) => {
    const res = await apiFetch<{product: Product}>(`/api/business/products/${productId}/stock`, {
      method: 'POST',
      body: JSON.stringify({delta}),
    });
    if (res.ok && res.data) {
      setProducts((prev) => prev.map((p) => (p.id === productId ? res.data!.product : p)));
    }
  };

  const createTradeTransaction = async (
    input: Omit<TradeTransaction, 'id' | 'businessId' | 'voucherNo'>
  ): Promise<TradeTransaction | null> => {
    const res = await apiFetch<{
      transaction: TradeTransaction;
      ledgerEntry: LedgerEntry | null;
    }>('/api/business/transactions', {
      method: 'POST',
      body: JSON.stringify(input),
    });
    if (res.ok && res.data) {
      if (authToken) {
        await loadBusinessWorkspaceWithToken(authToken);
      }
      return res.data.transaction;
    }
    return null;
  };

  const addCustomer = async (input: Omit<Customer, 'id' | 'businessId' | 'createdAt'>) => {
    const res = await apiFetch<{customer: Customer}>('/api/business/customers', {
      method: 'POST',
      body: JSON.stringify(input),
    });
    if (res.ok && res.data) {
      setCustomers((prev) => [res.data!.customer, ...prev]);
    }
  };

  const updateCustomer = async (customerId: string, updates: Partial<Customer>) => {
    const res = await apiFetch<{customer: Customer}>(`/api/business/customers/${customerId}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
    if (res.ok && res.data) {
      setCustomers((prev) => prev.map((c) => (c.id === customerId ? res.data!.customer : c)));
    }
  };

  const addLedgerEntry = async (input: Omit<LedgerEntry, 'id' | 'businessId'>) => {
    const res = await apiFetch<{entry: LedgerEntry}>('/api/business/ledger', {
      method: 'POST',
      body: JSON.stringify(input),
    });
    if (res.ok && res.data) {
      setLedgerEntries((prev) => [res.data!.entry, ...prev]);
    }
  };

  const addExpense = async (input: Omit<ExpenseRecord, 'id' | 'businessId'>) => {
    const res = await apiFetch<{expense: ExpenseRecord}>('/api/business/expenses', {
      method: 'POST',
      body: JSON.stringify(input),
    });
    if (res.ok && res.data) {
      setExpenses((prev) => [res.data!.expense, ...prev]);
    }
  };

  const deleteExpense = async (expenseId: string) => {
    const res = await apiFetch(`/api/business/expenses/${expenseId}`, {method: 'DELETE'});
    if (res.ok) {
      setExpenses((prev) => prev.filter((e) => e.id !== expenseId));
    }
  };

  const value: AppContextValue = {
    session,
    activeBusinessUser,
    users: session?.role === 'super_admin' ? users : [],
    adminStats: session?.role === 'super_admin' ? adminStats : EMPTY_STATS,
    products: session?.role === 'business_user' ? products : [],
    transactions: session?.role === 'business_user' ? transactions : [],
    customers: session?.role === 'business_user' ? customers : [],
    ledgerEntries: session?.role === 'business_user' ? ledgerEntries : [],
    expenses: session?.role === 'business_user' ? expenses : [],
    isSyncing,
    getAdminAuthStatus,
    setupAdminPasscode,
    loginAsSuperAdmin,
    loginAsBusinessUser,
    loginAsDemoBusiness,
    registerBusinessAccount,
    logout,
    refreshAdminUsers,
    setUserStatus,
    setUserBlocked,
    deleteUser,
    updateUserAndBusiness,
    addProduct,
    updateProduct,
    deleteProduct,
    adjustProductStock,
    createTradeTransaction,
    addCustomer,
    updateCustomer,
    addLedgerEntry,
    addExpense,
    deleteExpense,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
