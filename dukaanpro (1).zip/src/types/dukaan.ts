export type UserRole = 'super_admin' | 'business_user';

export type UserStatus = 'active' | 'deactivated';

export interface PlatformUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  businessId: string;
  businessName: string;
  businessCategory: string;
  city: string;
  state: string;
  gstin: string;
  status: UserStatus;
  isBlocked: boolean;
  ownerNotes?: string;
  joinedAt: string;
  lastActiveAt: string;
}

export interface Product {
  id: string;
  businessId: string;
  sku: string;
  name: string;
  category: string;
  unit: string;
  purchasePrice: number;
  sellingPrice: number;
  gstRate: number;
  stock: number;
  minStock: number;
  updatedAt: string;
}

export type TradeType = 'sale' | 'purchase';
export type PaymentMode = 'Cash' | 'UPI' | 'Udhar (Credit)' | 'Bank Transfer';

export interface TradeLineItem {
  productId: string;
  productName: string;
  qty: number;
  unit: string;
  rate: number;
  gstRate: number;
  lineTotal: number;
}

export interface TradeTransaction {
  id: string;
  businessId: string;
  voucherNo: string;
  type: TradeType;
  partyName: string;
  partyPhone: string;
  customerId?: string;
  items: TradeLineItem[];
  subtotal: number;
  gstAmount: number;
  totalAmount: number;
  paidAmount: number;
  dueAmount: number;
  paymentMode: PaymentMode;
  date: string;
  notes?: string;
}

export interface Customer {
  id: string;
  businessId: string;
  name: string;
  phone: string;
  city: string;
  gstin?: string;
  openingBalance: number;
  createdAt: string;
}

export type LedgerEntryType = 'udhar' | 'jama';

export interface LedgerEntry {
  id: string;
  businessId: string;
  customerId: string;
  customerName: string;
  type: LedgerEntryType;
  amount: number;
  mode: 'Cash' | 'UPI' | 'Bank Transfer' | 'Credit Bill';
  date: string;
  note: string;
  referenceVoucher?: string;
}

export type ExpenseCategory =
  | 'Rent'
  | 'Electricity & Internet'
  | 'Staff Salary'
  | 'Transport & Freight'
  | 'Packaging'
  | 'Shop Maintenance'
  | 'Other';

export interface ExpenseRecord {
  id: string;
  businessId: string;
  title: string;
  category: ExpenseCategory;
  amount: number;
  paymentMode: 'Cash' | 'UPI' | 'Bank Transfer';
  date: string;
  vendor?: string;
  notes?: string;
}

export interface AuthSession {
  role: UserRole;
  userId: string;
  email: string;
  name: string;
  businessId?: string;
}
